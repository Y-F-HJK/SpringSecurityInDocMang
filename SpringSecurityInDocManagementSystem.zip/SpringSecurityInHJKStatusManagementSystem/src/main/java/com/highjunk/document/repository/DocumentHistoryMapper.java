package com.highjunk.document.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.highjunk.document.dto.DocumentHistoryDto;
import com.highjunk.document.entity.DocumentHistoryEntity;

/**
 * 書類履歴 Mapper
 * @author HighJunk
 */
@Mapper
public interface DocumentHistoryMapper {

  /**
   * 履歴一覧テーブルへインサート
   * @param documentHistoryEntity 書類履歴エンティティ
   */
   void insert(DocumentHistoryEntity documentHistoryEntity);

   /**
    * 書類履歴エンティティの取得(新規作成時)
    * @param managementId 管理ID
    * @param documentId 書類ID
    * @return 書類履歴エンティティ
    */
  DocumentHistoryEntity getOneDocumentHistory(@Param("managementId") int managementId, @Param("documentId") String documentId);

  /**
   * ログインユーザーの書類履歴一覧取得
   * @param userId ログインユーザーID
   * @return 書類履歴エンティティリスト
   */
  List<DocumentHistoryEntity> getDocumentHistoryList(String userId);

  /**
   * 管理IDと書類IDで取得
   * @param managementId 管理id
   * @param documentId 書類id
   * @return 書類履歴dtoリスト
   */
  List<DocumentHistoryDto> getDocumentHistory(@Param("managementId") int managementId, @Param("documentId") String documentId);

/**
 * 検索用
 * @param documentId 管理id
 * @param userId ユーザーid
 * @param appFlg 申請中フラグ
 * @param completedFlg 完了フラグ
 * @param denialFlg 否認フラグ
 * @return 書類履歴エンティティ
 */
  List<DocumentHistoryEntity> searchDocumentHistory(
    @Param("documentId") String documentId, @Param("userId") String userId, @Param("appFlg") boolean appFlg,
    @Param("completedFlg") boolean completedFlg, @Param("denialFlg") boolean denialFlg);

}