package com.highjunk.document.dto;

import lombok.Data;

/**
 * 書類名Dto
 * @author HighJunk
 */
@Data
public class DocumentNameDto {

  // 書類ID
  private String documentId;
  // 書類名
  private String documentName;

}
