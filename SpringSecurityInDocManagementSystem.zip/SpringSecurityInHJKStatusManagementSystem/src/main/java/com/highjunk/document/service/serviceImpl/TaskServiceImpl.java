package com.highjunk.document.service.serviceImpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.highjunk.document.common.ClassificationCodeEnum;
import com.highjunk.document.common.DocumentCodeEnum;
import com.highjunk.document.common.WorkContentEnum;
import com.highjunk.document.entity.DocumentHistoryEntity;
import com.highjunk.document.entity.DocumentProgressManagementEntity;
import com.highjunk.document.entity.EmployeeMasterEntity;
import com.highjunk.document.entity.PromotionRequestEntity;
import com.highjunk.document.entity.TaskInfo;
import com.highjunk.document.repository.CodeMapper;
import com.highjunk.document.repository.DocumentHistoryMapper;
import com.highjunk.document.repository.DocumentProgressManagementMapper;
import com.highjunk.document.repository.EmployeeMasterMapper;
import com.highjunk.document.repository.PromotionRequestMapper;
import com.highjunk.document.service.TaskService;

/**
 * タスク一覧サービス実装クラス
 * @author HighJunk
 */
@Service
public class TaskServiceImpl implements TaskService {

  // コードマッパー
  @Autowired
  private CodeMapper codeMapper;

  // 書類履歴マッパー
  @Autowired
  private DocumentHistoryMapper documentHistoryMapper;

  // 書類進捗管理マッパー
  @Autowired
  private DocumentProgressManagementMapper documentProgressManagementMapper;

  // 社員マッパー
  @Autowired
  private EmployeeMasterMapper employeeMasterMapper;

  // 昇格申請書マッパー
  @Autowired
  private PromotionRequestMapper promotionRequestMapper;

  private SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

  /**
   * タスク一覧取得メソッド
   * @param userId ログインユーザーID
   * @return タスク一覧
   */
  @Override
  public List<TaskInfo> getTask(String userId) {

    // タスク一覧
    List<TaskInfo> taskList = new ArrayList<>();

    // 昇格申請書を取得
    List<PromotionRequestEntity> promotionRequestList = promotionRequestMapper.getPromotionRequestList(userId);

    // タスク内容を設定し、タスク一覧に追加
    taskList = promotionRequestList.stream()
        .map(p -> {
          // タスク情報
          TaskInfo taskInfo = new TaskInfo();

          // 管理ID、申請日を設定
          taskInfo.setManagementId(String.valueOf(p.getManagementId()));
          taskInfo.setApplicantDay(sdf.format(p.getCreateDate()));

          // 書類進捗管理を取得
          DocumentProgressManagementEntity documentProgressManagementEntity =
              documentProgressManagementMapper.getDocumentProgressManagement(DocumentCodeEnum.PROMOTIONREQUEST.getDocumentCode(), p.getManagementId());
          // 書類ID、進捗ステータスを設定
          taskInfo.setDocumentId(documentProgressManagementEntity.getDocumentId());
          taskInfo.setProgressStatus(documentProgressManagementEntity.getProgressStatus());

          // 社員情報を取得
          EmployeeMasterEntity targetEmployee = employeeMasterMapper.getEmployee(p.getTargetEmployeeId());
          EmployeeMasterEntity applicantEmployee = employeeMasterMapper.getEmployee(userId);
          // 書類の対象者、申請者名を設定
          taskInfo.setTargetName(targetEmployee.getEmployeeName());
          taskInfo.setApplicantName(applicantEmployee.getEmployeeName());

          // コードを取得
          String documentName =
              codeMapper.getProgressStatusContent(ClassificationCodeEnum.DOCUMENT.getClassificationCode(), documentProgressManagementEntity.getDocumentId());
          // 書類名を設定
          taskInfo.setDocumentName(documentName != null ? documentName : "");

          // 作業内容を設定
          switch(documentProgressManagementEntity.getProgressStatus()) {
            case "010":
              taskInfo.setWorkContent(WorkContentEnum.COMMENT.getWorkContent());
              break;
            case "020":
            case "100":
            case "200":
            case "300":
              taskInfo.setWorkContent(WorkContentEnum.APPROVAL.getWorkContent());
              break;
          }

          // 書類履歴を取得
          DocumentHistoryEntity documentHistoryEntity =
              documentHistoryMapper.getOneDocumentHistory(p.getManagementId(), documentProgressManagementEntity.getDocumentId());
          // 社員情報を取得
          EmployeeMasterEntity workRequester = employeeMasterMapper.getEmployee(documentHistoryEntity.getEmployeeId());
          // 作業依頼者、作業依頼日を設定
          taskInfo.setRequester(workRequester.getEmployeeName());
          taskInfo.setRequestDay(sdf.format(documentHistoryEntity.getCreateDate()));

          return taskInfo;
        }).collect(Collectors.toList());

    return taskList;

  }

}