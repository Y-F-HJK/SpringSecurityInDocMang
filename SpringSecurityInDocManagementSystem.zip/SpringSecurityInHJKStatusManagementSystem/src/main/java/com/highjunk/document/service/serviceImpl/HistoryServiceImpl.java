package com.highjunk.document.service.serviceImpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.highjunk.document.common.ClassificationCodeEnum;
import com.highjunk.document.dto.DocumentNameDto;
import com.highjunk.document.dto.HistoryInfoDto;
import com.highjunk.document.entity.CodeEntity;
import com.highjunk.document.entity.DocumentHistoryEntity;
import com.highjunk.document.entity.DocumentProgressManagementEntity;
import com.highjunk.document.entity.EmployeeMasterEntity;
import com.highjunk.document.entity.PromotionRequestEntity;
import com.highjunk.document.repository.CodeMapper;
import com.highjunk.document.repository.DocumentHistoryMapper;
import com.highjunk.document.repository.DocumentProgressManagementMapper;
import com.highjunk.document.repository.EmployeeMasterMapper;
import com.highjunk.document.repository.PromotionRequestMapper;
import com.highjunk.document.service.HistoryService;

/**
 * 履歴一覧サービス実装クラス
 * @author HighJunk
 */
@Service
public class HistoryServiceImpl implements HistoryService {

  // コードマッパー
  @Autowired
  private CodeMapper codeMapper;

  // 書類履歴マッパー
  @Autowired
  private DocumentHistoryMapper documentHistoryMapper;

  // 書類進捗管理マッパー
  @Autowired
  private DocumentProgressManagementMapper documentProgressManagementMapper;

  // 社員マッパー
  @Autowired
  private EmployeeMasterMapper employeeMasterMapper;

  // 昇格申請書マッパー
  @Autowired
  private PromotionRequestMapper promotionRequestMapper;

  private SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

  /**
   * 履歴一覧取得メソッド
   * @param userId ログインユーザーID
   * @return 履歴一覧
   */
  @Override
  public List<HistoryInfoDto> getHistory(String userId) {

    // 履歴一覧
    List<HistoryInfoDto> historyList = new ArrayList<>();

    // 書類履歴を取得
    List<DocumentHistoryEntity> documentHistoryList = documentHistoryMapper.getDocumentHistoryList(userId);

    // グルーピング用複合キー作成(書類ID,管理ID)
    Function<DocumentHistoryEntity, String> compositeKey = d -> {
      StringBuffer sb = new StringBuffer();
      sb.append(d.getDocumentId()).append("-").append(d.getManagementId());
      return sb.toString();
    };

    if (!CollectionUtils.isEmpty(documentHistoryList)) {
      // 管理IDおよび書類IDで絞り込み、管理ID、書類IDを取得
      Map<String, List<DocumentHistoryEntity>> documentHistoryMap =
          documentHistoryList.stream().collect(Collectors.groupingBy(compositeKey));

      // 履歴一覧に追加
      for (Map.Entry<String, List<DocumentHistoryEntity>> map : documentHistoryMap.entrySet()) {
        // 履歴情報Dto
        HistoryInfoDto historyInfoDto = new HistoryInfoDto();

        String key = map.getKey();

        // 管理ID
        String managementId = key.substring(key.indexOf("-") + 1);
        // 書類ID
        String documentId = key.substring(0, key.indexOf("-"));

        // 管理ID、書類IDを設定
        historyInfoDto.setManagementId(managementId);
        historyInfoDto.setDocumentId(documentId);

        // コードを取得
        String documentName =
            codeMapper.getProgressStatusContent(ClassificationCodeEnum.DOCUMENT.getClassificationCode(), documentId);
        // 書類名を設定
        historyInfoDto.setDocumentName(documentName != null ? documentName : "");

        // 昇格申請書を取得
        PromotionRequestEntity promotionRequestEntity = promotionRequestMapper.findByManagementId(Integer.parseInt(managementId));
        // 社員情報を取得
        EmployeeMasterEntity employeeMasterEntity = employeeMasterMapper.getEmployee(promotionRequestEntity.getApplicantEmployeeId());
        // 申請者名を設定
        historyInfoDto.setApplicantName(employeeMasterEntity.getEmployeeName());

        // 作成日の降順に並び替え
        Optional<DocumentHistoryEntity> documentHistoryEntityOpt = map.getValue()
            .stream()
            .sorted(Comparator.comparing(DocumentHistoryEntity::getCreateDate).reversed())
            .findFirst();

        // 作成日、進捗ステータスを設定
        if(documentHistoryEntityOpt.isPresent()) {
          DocumentHistoryEntity documentHistoryEntity = documentHistoryEntityOpt.get();

          historyInfoDto.setCreateDate(documentHistoryEntity.getCreateDate() != null ?
              sdf.format(documentHistoryEntity.getCreateDate()) : null);

          // 書類進捗管理情報を取得
          DocumentProgressManagementEntity documentProgressManagementEntity =
              documentProgressManagementMapper.getDocumentProgressManagement(documentId, Integer.parseInt(managementId));

          // コードを取得
          String progressStatusContent =
              codeMapper.getProgressStatusContent(ClassificationCodeEnum.PROGRESS.getClassificationCode(), documentProgressManagementEntity.getProgressStatus());
          historyInfoDto.setProgressStatus(progressStatusContent != null ? progressStatusContent : "");
        }

        historyList.add(historyInfoDto);
      }
    }

    List<HistoryInfoDto> sortedHistoryList =
        historyList.stream().sorted(Comparator.comparing(HistoryInfoDto::getCreateDate).reversed()).collect(Collectors.toList());

    return sortedHistoryList;

  }

  /**
   * 書類名一覧取得メソッド
   * @return 書類名一覧
   */
  @Override
  public List<DocumentNameDto> getDocumentName() {

    // 書類名一覧
    List<DocumentNameDto> documentNameList = new ArrayList<>();

    // 書類名一覧を取得
    List<CodeEntity> codeList = 
        codeMapper.getCodeList(ClassificationCodeEnum.DOCUMENT.getClassificationCode());

    // 書類名一覧を設定
    for (CodeEntity code : codeList) {
      DocumentNameDto documentNameDto = new DocumentNameDto();
      documentNameDto.setDocumentId(code.getCode());
      documentNameDto.setDocumentName(code.getCodeName());
      documentNameList.add(documentNameDto);
    }

    return documentNameList;

  }

}