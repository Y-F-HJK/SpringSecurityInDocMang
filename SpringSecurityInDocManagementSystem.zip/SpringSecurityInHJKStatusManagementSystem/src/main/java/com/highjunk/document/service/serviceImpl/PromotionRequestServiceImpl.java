package com.highjunk.document.service.serviceImpl;

import java.util.Date;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.highjunk.document.entity.DocumentHistoryEntity;
import com.highjunk.document.entity.DocumentProgressManagementEntity;
import com.highjunk.document.entity.PromotionRequestEntity;
import com.highjunk.document.form.PromotionRequestForm;
import com.highjunk.document.repository.DocumentHistoryMapper;
import com.highjunk.document.repository.DocumentProgressManagementMapper;
import com.highjunk.document.repository.PromotionRequestMapper;
import com.highjunk.document.service.PromotionRequestService;

/**
 * 昇格申請サービスImpl
 * @author HighJunk
 */
@Service
public class PromotionRequestServiceImpl implements PromotionRequestService {

  @Autowired
  private PromotionRequestMapper promotionRequestMapper;

  @Autowired
  private DocumentProgressManagementMapper documentProgressManagementMapper;

  @Autowired
  private DocumentHistoryMapper documentHistoryMapper;

  /**
   * 昇格申請データベース登録処理
   * @param 昇格申請フォーム
   * @return 成功時true
   */
  public Boolean savePromotionRequest(PromotionRequestForm form){

    // 昇格申請書類エンティティの生成
    PromotionRequestEntity promotionRequestEntity = new PromotionRequestEntity();
    // フォームの中身をエンティティに値をset
    promotionRequestEntity.setApplicantEmployeeId(form.getUserId());
    promotionRequestEntity.setTargetEmployeeId(form.getTargetId());
    promotionRequestEntity.setBeforePositionId(form.getPositionCode());
    promotionRequestEntity.setAfterPositionId(form.getAfterPositionCode());
    promotionRequestEntity.setApplicantComment(form.getComment());
    Date nowDate = new Date();
    promotionRequestEntity.setCreateDate(nowDate);

    // 昇格申請書類テーブルへインサート
    promotionRequestMapper.insert(promotionRequestEntity);

    // 昇格申請書類テーブルからインサートしたレコードのmangement_idを取得
    int managementId = promotionRequestMapper.findByLatestCreateDate();

    // 昇格書類の書類ID
    String documentId = "001";

    // 進捗ステータス(申請時は「部下承認待ち」)
    String progressStatus ="010";

    // 書類進捗管理エンティティの生成
    DocumentProgressManagementEntity documentProgressManagementEntity = new DocumentProgressManagementEntity();
    // 書類進捗管理エンティティに値をset
    documentProgressManagementEntity.setManagementId(managementId);
    documentProgressManagementEntity.setDocumentId(documentId);
    documentProgressManagementEntity.setEmployeeId(form.getNextWriterId());
    documentProgressManagementEntity.setProgressStatus(progressStatus);
    documentProgressManagementEntity.setCreateDate(nowDate);

    // 書類進捗管理テーブルへインサート
    documentProgressManagementMapper.insert(documentProgressManagementEntity);

    // 書類履歴エンティティの生成
    DocumentHistoryEntity documentHistoryEntity = new DocumentHistoryEntity();
    // 書類履歴エンティティに値をset
    documentHistoryEntity.setManagementId(managementId);
    documentHistoryEntity.setDocumentId(documentId);
    documentHistoryEntity.setEmployeeId(form.getNextWriterId());
    documentHistoryEntity.setProgressStatus(progressStatus);
    documentHistoryEntity.setCreateDate(nowDate);

    // 書類履歴一覧テーブルへインサート
    documentHistoryMapper.insert(documentHistoryEntity);

    // 処理終了確認のため書類履歴テーブルより先ほどインサートしたレコードを取得
    DocumentHistoryEntity documentHistoryEntityCheck =
        documentHistoryMapper.getOneDocumentHistory(documentHistoryEntity.getManagementId(), documentHistoryEntity.getDocumentId());

    // インスタンス存在チェック
    // フラグ返却
    if (ObjectUtils.isNotEmpty(documentHistoryEntityCheck)) {
      return true;
    } else {
      return false;
    }

    
  }
}
