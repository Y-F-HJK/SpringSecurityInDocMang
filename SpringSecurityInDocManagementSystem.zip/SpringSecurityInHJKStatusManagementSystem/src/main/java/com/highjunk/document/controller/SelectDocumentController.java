package com.highjunk.document.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.highjunk.document.dto.DocumentDto;
import com.highjunk.document.dto.EmployeeMasterDto;
import com.highjunk.document.dto.MyUser;
import com.highjunk.document.dto.PositionDto;
import com.highjunk.document.service.SelectDocumentService;

/**
 * 書類選択画面コントローラー
 * @author HighJunk
 */
@Controller
@RequestMapping("/documentSelection")
public class SelectDocumentController {

  @Autowired
  private SelectDocumentService selectDocumentServiceImpl;

  /**
   * 書類選択画面へ遷移
   * @param userId ユーザーID
   * @param model
   * @return 書類リスト、役職リスト、社員リスト、ユーザーID
   */
  @GetMapping("")
  public String documentSelection(@AuthenticationPrincipal MyUser user, Model model) {
    // 書類リスト
    List<DocumentDto> documentList = selectDocumentServiceImpl.createDocumentList();

    // 役職リスト
    List<PositionDto> positionList = selectDocumentServiceImpl.createPositionList();

    // 社員リスト
    List<EmployeeMasterDto> employeeList = selectDocumentServiceImpl.createEmployeeList();

    model.addAttribute("positionList", positionList);
    model.addAttribute("employeeList", employeeList);
    model.addAttribute("documentList", documentList);
    model.addAttribute("userId", user.getUsername());
    return "documentSelection/index";
  }
}