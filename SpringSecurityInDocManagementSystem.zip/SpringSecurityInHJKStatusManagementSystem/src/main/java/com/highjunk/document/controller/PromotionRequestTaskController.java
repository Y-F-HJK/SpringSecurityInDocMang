package com.highjunk.document.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.highjunk.document.dto.PromotionRequestTaskDetailDto;
import com.highjunk.document.form.PromotionRequestTaskForm;
import com.highjunk.document.form.TaskCommentForm;
import com.highjunk.document.service.PromotionRequestTaskService;

/**
 * タスク詳細情報取得コントローラー
 * @author HighJunk
 */
@RestController
public class PromotionRequestTaskController {

  @Autowired
  private PromotionRequestTaskService promotionRequestTaskServiceImpl;

  @PostMapping("/getPromotionRequestTaskDetail")
  /**
   * タスク詳細情報取得
   * @param form フォーム入力内容
   * @return タスク詳細情報
   */
  public PromotionRequestTaskDetailDto getPrTaskDetail(@RequestBody PromotionRequestTaskForm form) {

    PromotionRequestTaskDetailDto prTaskDetail = promotionRequestTaskServiceImpl.getTaskDetail(String.valueOf(form.getManagementId()));
    return prTaskDetail;

  }

  @RequestMapping(value = "/updatePromotionRequest",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
  /**
   * タスク情報更新
   * @param form タスクコメントフォーム
   * @return 成功時true
   */
  public ResponseEntity<Boolean> updatePromotionRequest(@RequestBody TaskCommentForm form) {

    Boolean resultFlg = null;
    try {
      // データベース反映処理
      resultFlg = promotionRequestTaskServiceImpl.updatePromotionRequest(form);

    }catch(IOException e) {
      // 独自例外処理
    }

    // フラグ返却
    return ResponseEntity.ok(resultFlg);

  }
}