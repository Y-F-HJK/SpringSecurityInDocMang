package com.highjunk.document.common;

import lombok.Getter;

/**
 * 進捗ステータス管理enum
 * @author HighJunk
 *
 */
@Getter
public enum ProgressStatusEnum {
  /** 作成 */
  CREATE("001"),
  /** 申請済み(部下更新待ち) */
  APPLIED("010"),
  /** 部下コメント済み(上司承認待ち) */
  COMMENTED("020"),
  /** 上司承認済み(役員承認待ち) */
  BOSSAPPROVED("100"),
  /** 役員1人目承認済み(役員2人目承認待ち) */
  EXECUTIVEAPPROVED1("200"),
  /** 役員2人目承認済み(社長承認待ち) */
  EXECUTIVEAPPROVED2("300"),
  /** 社長承認済み */
  PRESIDENTAPPROVED("400"),
  /** 否認 */
  DENIAL("999");

  // 進捗ステータス
  private final String progressStatus;

  /**
   * コンストラクタ
   * @param progressStatus 進捗ステータス
   */
  private ProgressStatusEnum(String progressStatus) {
    this.progressStatus = progressStatus;
  }

}
