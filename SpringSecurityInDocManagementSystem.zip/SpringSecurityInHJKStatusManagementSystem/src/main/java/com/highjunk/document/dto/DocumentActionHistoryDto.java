package com.highjunk.document.dto;

import lombok.Data;

/**
 * 行動履歴
 * @author HighJunk
 *
 */
@Data
public class DocumentActionHistoryDto {
  // 実行日
  private String actionDay;
  // 実行者
  private String actionUserName;
  // 実行内容
  private String actionContent;
}