package com.highjunk.document.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.highjunk.document.dto.DocumentNameDto;
import com.highjunk.document.dto.HistoryInfoDto;
import com.highjunk.document.dto.MyUser;
import com.highjunk.document.service.HistoryService;

/**
 * 履歴一覧コントローラー
 * @author HighJunk
 */
@Controller
@RequestMapping("/history")
public class HistoryController {

  @Autowired
  private HistoryService historyService;

  /**
   * 履歴一覧表示
   * @param uesrId ログインユーザーID
   * @param model
   * @return
   */
  @GetMapping("")
  public String index(@AuthenticationPrincipal MyUser user, Model model) {

    // 履歴一覧を取得
    List<HistoryInfoDto> historyList = historyService.getHistory(user.getUsername());

    // 書類名リストを取得
    List<DocumentNameDto> documentNameList = historyService.getDocumentName();

    model.addAttribute("historyList", historyList);
    model.addAttribute("documentNameList", documentNameList);
    model.addAttribute("userId", user.getUsername());

    return "history/index";
  }

}