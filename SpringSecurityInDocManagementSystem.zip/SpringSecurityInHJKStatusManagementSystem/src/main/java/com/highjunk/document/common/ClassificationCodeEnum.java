package com.highjunk.document.common;

import lombok.Getter;

/**
 * 分類コード管理enum
 * @author HighJunk
 */
@Getter
public enum ClassificationCodeEnum {

  /** 進捗 */
  PROGRESS("5000"),
  /** 部署 */
  DEPARTMENT("0001"),
  /** 役職 */
  POSITION("0100"),
  /** 書類 */
  DOCUMENT("1000");

  // 分類コード
  private final String classificationCode;

  /**
   * コンストラクタ
   * @param classificationCode 分類コード
   */
  private ClassificationCodeEnum(String classificationCode) {
    this.classificationCode = classificationCode;
  }

}