package com.highjunk.document.dto;

import lombok.Data;

/**
 * 社員情報Dto
 * @author SysAdmin
 */
@Data
public class EmployeeMasterDto {
	
  // 社員id
  private String employeeId;
  // 社員名
  private String employeeName;

}