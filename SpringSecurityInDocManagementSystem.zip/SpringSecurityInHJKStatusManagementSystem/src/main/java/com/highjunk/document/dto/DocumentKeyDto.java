package com.highjunk.document.dto;

import lombok.Data;

/**
 * 書類のkey格納するDto
 * @author HighJunk
 *
 */
@Data
public class DocumentKeyDto {
  // 管理ID
  private String managementId;
  // 書類ID
  private String documentId;
}
