package com.highjunk.document.entity;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;

import lombok.Data;

/**
 * 社員マスタエンティティ
 * @author HighJunk
 *
 */
@Data
public class EmployeeMasterEntity {
  // 社員ID
  private String employeeId;
  // 社員名
  private String employeeName;
  // メールアドレス
  @Email
  @Max(value = 256)
  private String mailAddress;
  // 部署ID
  private String departmentId;
  // 役職ID
  private String positionId;
}