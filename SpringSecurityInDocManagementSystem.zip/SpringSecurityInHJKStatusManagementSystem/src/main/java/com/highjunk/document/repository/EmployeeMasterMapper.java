package com.highjunk.document.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.highjunk.document.dto.EmployeeMasterDto;
import com.highjunk.document.entity.EmployeeMasterEntity;

/**
 * 社員マスタ Mapper
 * @author HighJunk
 */
@Mapper
public interface EmployeeMasterMapper {

  /**
   * 全社員のid,名前取得
   * @return 社員情報Dto
   */
  List<EmployeeMasterDto> getAllEmployee();

  /**
   * 社員取得
   * @param employeeId 社員ID
   * @return 社員エンティティ
   */
  EmployeeMasterEntity getEmployee(String employeeId);

  /**
   * 社員名取得
   * @param employeeId 社員ID
   * @return 社員名
   */
  String getEmployeeName(String employeeId);

}