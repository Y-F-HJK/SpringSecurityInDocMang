package com.highjunk.document.dto;

import lombok.Data;

/**
 * 役職Dto
 * @author HighJunk
 */
@Data
public class PositionDto {

  /**
   * 役職ID
   */
  private String positionId;

  /**
   * 役職名
   */
  private String positionName;

}