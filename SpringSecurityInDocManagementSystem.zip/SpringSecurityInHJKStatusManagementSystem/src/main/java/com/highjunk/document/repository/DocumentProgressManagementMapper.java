package com.highjunk.document.repository;

import java.util.Date;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.highjunk.document.entity.DocumentProgressManagementEntity;

/**
 * 書類進捗管理 Mapper
 * @author HighJunk
 */
@Mapper
public interface DocumentProgressManagementMapper {

  // 進捗管理テーブルへインサート
  @Insert("insert into document_progress_management (management_id, document_id, employee_id, progress_status, create_date)"
      + "values (#{managementId}, #{documentId}, #{employeeId}, #{progressStatus}, #{createDate})")
  void insert(DocumentProgressManagementEntity DPM);

  // 書類進捗管理取得
  DocumentProgressManagementEntity getDocumentProgressManagement(
      @Param("documentId") String documentId, @Param("managementId") int managementId);

  // 管理IDと書類IDで取得
  @Select("select * from document_progress_management where management_id = #{managementId} and document_id = #{documentId}")
  DocumentProgressManagementEntity findByManagementIdAndDocumentId(Integer managementId, String documentId);

   // 進捗ステータスのupdate
  @Update("update document_progress_management SET progress_status = #{status} where management_id = #{id}")
  void updateProgressStatus(String status, Integer id);

  // 次回作業者のupdate
  @Update("update document_progress_management SET employee_id = #{nextWriter} where management_id = #{id}")
  void updateEmployeeId(String nextWriter, Integer id);
  
  // 更新日のupdate
  @Update("update document_progress_management SET update_date = #{today} where management_id = #{managementId}")
  void updateUpdateDate(Date today, Integer managementId);
  
  //タスク削除処理
  @Delete("delete from document_progress_management where management_id = #{managementId}")
  void delete(Integer managementId);
}