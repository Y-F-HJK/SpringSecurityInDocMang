package com.highjunk.document.service;

import java.util.List;

import com.highjunk.document.entity.TaskInfo;

/**
 * タスク一覧サービス
 * @author HighJunk
 */
public interface TaskService {

  /**
   * タスク一覧取得メソッド
   * @param userId ログインユーザーID
   * @return タスク一覧
   */
  public List<TaskInfo> getTask(String userId);

}