package com.highjunk.document;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;


@Configuration
@EnableWebSecurity
@Import({MySessionListener.class})
public class SecurityConfig extends WebSecurityConfigurerAdapter {

  @Autowired
  private UserDetailsService userDetailsService;

  @Bean
  public BCryptPasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }

  @Override
  public void configure(WebSecurity web) throws Exception {
    // セキュリティ設定を無視するリクエスト設定
    // 静的リソース(images、css、javascript)に対するアクセスはセキュリティ設定を無視する
    web.ignoring().antMatchers(
      "/img/**",
      "/css/**",
      "/js/**",
      "/webjars/**"
    );
  }

  @Override
  protected void configure(HttpSecurity http) throws Exception{
    http
      .authorizeRequests()
      // /loginは全ユーザーがアクセス可能
      .antMatchers("/login","/timeout").permitAll()
      //上記以外へのアクセスは認証が必要
      .anyRequest().authenticated()
      .and()
      .rememberMe()   // ログイン状態を保持する
      .and()
      //ログインの設定
      .formLogin()
      .loginPage("/login")
      .usernameParameter("loginId")
      .passwordParameter("loginPassword")
      .defaultSuccessUrl("/menu", true)
      .and()
      .logout()
      .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
      .invalidateHttpSession(true);
  }

  @Override
  protected void configure(AuthenticationManagerBuilder auth) throws Exception {

    auth 
      .userDetailsService(userDetailsService);

  }
}