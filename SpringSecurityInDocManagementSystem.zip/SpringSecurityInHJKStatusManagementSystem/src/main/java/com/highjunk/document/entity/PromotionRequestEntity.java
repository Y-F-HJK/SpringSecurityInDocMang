package com.highjunk.document.entity;

import java.util.Date;

import lombok.Data;

/**
 * 昇格申請書テーブルエンティティ
 * @author HighJunk
 *
 */
@Data
public class PromotionRequestEntity {
  // 管理ID
  private int managementId;
  // 現役職ID
  private String beforePositionId;
  // 昇格後役職ID
  private String afterPositionId;
  // 申請者ID
  private String applicantEmployeeId;
  // 対象者ID
  private String targetEmployeeId;
  // 申請者コメント
  private String applicantComment;
  // 昇格対象者コメント
  private String targetComment;
  // 評価者コメント1
  private String officerComment1;
  // 評価者コメント2
  private String officerComment2;
  // 評価者コメント3
  private String officerComment3;
  // 承認日
  private Date approvalDate;
  // 作成日
  private Date createDate;
  // 更新日
  private Date updateDate;
}