package com.highjunk.document.form;

import java.io.Serializable;

import lombok.Data;

/**
 * 昇格申請フォーム
 * @author HighJunk
 *
 */
@Data
public class PromotionRequestForm implements Serializable {

  private static final long serialVersionUID = 1L;

  private String userId;

  private String targetId;

  private String positionCode;

  private String afterPositionCode;

  private String comment;

  private String nextWriterId;

}
