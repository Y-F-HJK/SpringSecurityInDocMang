package com.highjunk.document.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.highjunk.document.form.PromotionRequestForm;
import com.highjunk.document.service.PromotionRequestService;

/**
 * 昇格申請用レストコントローラー
 * @author HighJunk
 */
@RestController
public class PromotionRequestController {

  @Autowired
  private PromotionRequestService promotionRequestServiceImpl;

  @RequestMapping(value = "/savePromotionRequest",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)

  /**
   * 昇格申請TBL登録
   * @param form
   * @return　フラグ
   */
  public ResponseEntity<?> savePromotionRequest(@RequestBody PromotionRequestForm form) {

    // データベース反映処理
    Boolean resultFlg = promotionRequestServiceImpl.savePromotionRequest(form);

    // フラグ返却
    return ResponseEntity.ok(resultFlg);

  }
}
