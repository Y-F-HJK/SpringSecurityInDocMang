package com.highjunk.document.dto;

import java.util.List;

import lombok.Data;

/**
 * 書類詳細クラスDto
 * @author HighJunk
 *
 */
@Data
public class DocumentHistoryDetailDto {
  // 書類作成日
  private String createDate;
  // 書類完成日
  private String completeDate;
  // 申請者コメント
  private String applicantComment;
  // 対象者コメント
  private String targetComment;
  // 評価者コメント1
  private String officerComment1;
  // 評価者コメント2
  private String officerComment2;
  // 評価者コメント3
  private String officerComment3;
  // 行動履歴リスト
  private List<DocumentActionHistoryDto> documentActionHistoryList;
}