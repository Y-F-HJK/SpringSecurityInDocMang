package com.highjunk.document.repository;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.highjunk.document.entity.PromotionRequestEntity;

/**
 * 昇格申請書 Mapper
 * @author HighJunk
 */
@Mapper
public interface PromotionRequestMapper {

  // 昇格申請書類テーブルへインサート
  @Insert("insert into promotion_request (applicant_employee_id,target_employee_id, before_position_id,after_position_id,applicant_comment,create_date) "
      + "values (#{applicantEmployeeId}, #{targetEmployeeId}, #{beforePositionId}, #{afterPositionId}, #{applicantComment}, #{createDate})")
  void insert(PromotionRequestEntity promotionRequestEntity);

  // 最新の書類申請書類レコードのmanagement_idを取得
  @Select ("select management_id from promotion_request order by create_date desc limit 1;")
  int findByLatestCreateDate();

  @Select("select * from promotion_request where management_id = #{managementId}")
  PromotionRequestEntity findByManagementId(Integer managementId);

  // ログインユーザーの昇格申請書一覧取得
  List<PromotionRequestEntity> getPromotionRequestList(String userId);

  // 対象者コメントのupdate
  @Update("update promotion_request SET target_comment = #{comment} where management_id = #{managementId}")
  void updateTargetComment(String comment, Integer managementId);
  
  // 評価者コメント1のupdate
  @Update("update promotion_request SET officer_comment1 = #{comment} where management_id = #{managementId}")
  void updateOfficerComment1(String comment, Integer managementId);
  
  // 評価者コメント2のupdate
  @Update("update promotion_request SET officer_comment2 = #{comment} where management_id = #{managementId}")
  void updateOfficerComment2(String comment, Integer managementId);
  
  // 評価者コメント3のupdate
  @Update("update promotion_request SET officer_comment3 = #{comment} where management_id = #{managementId}")
  void updateOfficerComment3(String comment, Integer managementId);
  
  // 更新日のupdate
  @Update("update promotion_request SET update_date = #{today} where management_id = #{managementId}")
  void updateUpdateDate(Date today, Integer managementId);

  // 承認日のupdate
  @Update("update promotion_request SET approval_date = #{today} where management_id = #{managementId}")
  void updateApprovalDate(Date today, Integer managementId);

}