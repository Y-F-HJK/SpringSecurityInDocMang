package com.highjunk.document;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.springframework.beans.factory.annotation.Autowired;

import com.highjunk.document.controller.LoginController;

public class MySessionListener implements HttpSessionListener {

  @Autowired
  LoginController loginController;

  @Override
  public void sessionCreated(HttpSessionEvent se) {
    // タイムアウト時間を設定
    HttpSession session = se.getSession();
    session.setMaxInactiveInterval(10);
  }

  @Override
  public void sessionDestroyed(HttpSessionEvent se) {
    loginController.timeout();
  }
}