package com.highjunk.document;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestHighJunkDocumentManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestHighJunkDocumentManagementApplication.class, args);
	}
}
