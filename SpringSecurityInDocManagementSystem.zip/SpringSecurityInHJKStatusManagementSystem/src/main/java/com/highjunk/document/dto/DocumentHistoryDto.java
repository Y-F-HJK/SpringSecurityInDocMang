package com.highjunk.document.dto;

import java.util.Date;

import lombok.Data;

/**
 * 書類履歴Dto
 * @author HighJunk
 *
 */
@Data
public class DocumentHistoryDto {
  // 社員ID
  private String employeeId;
  // 進捗ステータス
  private String progressStatus;
  // 作成日
  private Date createDate;
}
