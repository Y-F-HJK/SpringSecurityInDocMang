package com.highjunk.document.entity;

import lombok.Data;

/**
 * ユーザー情報テーブル
 * @author HighJunk
 *
 */
@Data
public class UserInfoEntity {
  // 社員ID
  private String employeeId;
  // パスワード
  private String password;
}