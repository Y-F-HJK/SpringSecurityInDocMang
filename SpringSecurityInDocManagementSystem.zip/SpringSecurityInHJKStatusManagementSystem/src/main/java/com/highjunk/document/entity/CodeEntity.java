package com.highjunk.document.entity;

import lombok.Data;

/**
 * コードテーブルエンティティ
 * @author HighJunk
 *
 */
@Data
public class CodeEntity {
  // 分類コード
  private String bunruiCode;
  // 分類名
  private String bunruiName;
  // コード値
  private String code;
  // コード名
  private String codeName;
}