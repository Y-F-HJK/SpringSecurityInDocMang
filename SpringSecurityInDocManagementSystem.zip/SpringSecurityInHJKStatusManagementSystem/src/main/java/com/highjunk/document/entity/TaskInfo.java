package com.highjunk.document.entity;

import lombok.Data;

/**
 * タスク情報
 * @author HighJunk
 */
@Data
public class TaskInfo {

  // 管理ID
  private String managementId;
  // 書類ID
  private String documentId;
  // 書類の対象者
  private String targetName;
  // 申請者名
  private String applicantName;
  // 書類名
  private String documentName;
  // 申請日
  private String applicantDay;
  // 進捗ステータス
  private String progressStatus;
  // 作業内容
  private String workContent;
  // 作業依頼者
  private String requester;
  // 作業依頼日
  private String requestDay;

}