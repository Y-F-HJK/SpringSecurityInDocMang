package com.highjunk.document.form;

import lombok.Data;

/**
 * 昇格申請書履歴一覧詳細取得フォーム
 * @author HighJunk
 *
 */
@Data
public class DocumentHistoryDetailForm {
  // 管理ID
  private String managementId;
  // 書類ID
  private String documentId;
}