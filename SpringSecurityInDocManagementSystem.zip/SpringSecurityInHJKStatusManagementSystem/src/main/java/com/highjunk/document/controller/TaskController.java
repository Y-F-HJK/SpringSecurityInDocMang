package com.highjunk.document.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.highjunk.document.dto.MyUser;
import com.highjunk.document.entity.TaskInfo;
import com.highjunk.document.service.TaskService;

/**
 * タスク一覧コントローラー
 * @author HighJunk
 */
@Controller
@RequestMapping("/tasks")
public class TaskController {

  @Autowired
  public TaskService taskService;

  /**
   * タスク一覧表示
   * @param userId ログインユーザーID
   * @param model
   * @return
   */
  @GetMapping("")
  public String index(@AuthenticationPrincipal MyUser user, Model model) {

    // タスク一覧を取得
    List<TaskInfo> taskList = taskService.getTask(user.getUsername());

    model.addAttribute("taskList", taskList);
    model.addAttribute("userId", user.getUsername());

    return "taskList";
  }

}