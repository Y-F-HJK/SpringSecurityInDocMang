package com.highjunk.document.form;

import lombok.Data;

/**
 * 書類履歴取得検索フォーム
 * @author HighJunk
 *
 */
@Data
public class DocumentHistorySearchForm {
  // ログインユーザーID
  private String userId;
  // 書類ID
  private String documentId;
  // 申請中フラグ
  private Boolean appFlg;
  // 完了フラグ
  private Boolean completedFlg;
  // 否認フラグ
  private Boolean denialFlg;
}