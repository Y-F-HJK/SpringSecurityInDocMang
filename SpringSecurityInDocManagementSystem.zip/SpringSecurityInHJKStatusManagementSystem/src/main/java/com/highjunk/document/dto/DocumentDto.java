package com.highjunk.document.dto;

import lombok.Data;

/**
 * 書類Dto
 * @author HighJunk
 */
@Data
public class DocumentDto {

  /**
   * 書類ID
   */
  private String documentId;

  /**
   * 書類名
   */
  private String documentName;

}