package com.highjunk.document.form;

import java.io.Serializable;

import lombok.Data;

/**
 * タスクフォーム
 * @author HighJunk
 */
@Data
public class TaskCommentForm implements Serializable {
  
	private static final long serialVersionUID = 1L;
  
  // ユーザID
  private String userId;
  // 申請者コメント
  private String comment;
  // 進捗ステータス
  private String progressStatus;
  // 管理ID
  private int managementId;
}