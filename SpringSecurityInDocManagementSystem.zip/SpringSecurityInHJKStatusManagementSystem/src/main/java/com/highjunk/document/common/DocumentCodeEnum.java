package com.highjunk.document.common;

import lombok.Getter;

/**
 * 書類コード管理enum
 * @author HighJunk
 */
@Getter
public enum DocumentCodeEnum {

  /** 昇格申請書 */
  PROMOTIONREQUEST("001");

  // 書類コード
  private final String documentCode;

  /**
   * コンストラクタ
   * @param documentCode 書類コード
   */
  private DocumentCodeEnum(String documentCode) {
    this.documentCode = documentCode;
  }

}