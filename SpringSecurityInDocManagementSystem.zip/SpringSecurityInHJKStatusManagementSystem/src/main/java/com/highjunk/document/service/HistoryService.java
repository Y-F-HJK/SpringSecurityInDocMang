package com.highjunk.document.service;

import java.util.List;

import com.highjunk.document.dto.DocumentNameDto;
import com.highjunk.document.dto.HistoryInfoDto;

/**
 * 履歴一覧サービス
 * @author HighJunk
 */
public interface HistoryService {

  /**
   * 履歴一覧取得メソッド
   * @param userId ログインユーザーID
   * @return 履歴一覧
   */
  public List<HistoryInfoDto> getHistory(String userId);

  /**
   * 書類名一覧取得メソッド
   * @return 書類名一覧
   */
  public List<DocumentNameDto> getDocumentName();

}