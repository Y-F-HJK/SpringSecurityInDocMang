package com.highjunk.document.service;

import java.io.IOException;

import com.highjunk.document.dto.PromotionRequestTaskDetailDto;
import com.highjunk.document.form.TaskCommentForm;

public interface PromotionRequestTaskService {

  /**
   * タスク詳細情報取得
   * @param manegementId 管理ID
   * @return タスク詳細情報
   */
  public PromotionRequestTaskDetailDto getTaskDetail(String managementId);

  /**
   * タスク情報更新
   * @param form タスクコメントフォーム
   * @return 成功時true
   */
  public boolean updatePromotionRequest(TaskCommentForm form) throws IOException ;
}
