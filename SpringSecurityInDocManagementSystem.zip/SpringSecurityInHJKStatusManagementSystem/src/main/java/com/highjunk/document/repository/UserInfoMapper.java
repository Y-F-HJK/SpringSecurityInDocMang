package com.highjunk.document.repository;

import org.apache.ibatis.annotations.Mapper;

import com.highjunk.document.entity.UserInfoEntity;

/**
 * ユーザー情報 Mapper
 * @author HighJunk
 */
@Mapper
public interface UserInfoMapper {
   // ユーザー情報テーブルよりidと一致するレコードを取得
   UserInfoEntity findById(String id);
}
