package com.highjunk.document.entity;

import java.util.Date;

import lombok.Data;

/**
 * 書類履歴テーブルエンティティ
 * @author HighJunk
 *
 */
@Data
public class DocumentHistoryEntity {
  // 管理ID
  private int managementId;
  // 書類ID
  private String documentId;
  // 社員ID
  private String employeeId;
  // 進捗ステータス
  private String progressStatus;
  // 作成日
  private Date createDate;
}