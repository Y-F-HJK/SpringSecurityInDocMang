package com.highjunk.document.dto;

import lombok.Data;

/**
 * 履歴情報Dto
 * @author HighJunk
 */
@Data
public class HistoryInfoDto {

  // 管理ID
  private String managementId;
  // 書類ID
  private String documentId;
  // 作成日
  private String createDate;
  // 書類名
  private String documentName;
  // 申請者名
  private String applicantName;
  // 進捗ステータス
  private String progressStatus ;

}