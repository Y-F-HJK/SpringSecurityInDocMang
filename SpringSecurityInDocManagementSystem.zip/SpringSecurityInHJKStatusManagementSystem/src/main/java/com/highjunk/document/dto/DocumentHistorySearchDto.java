package com.highjunk.document.dto;

import lombok.Data;

/**
 * 書類履歴一覧検索Dto
 * @author HighJunk
 *
 */
@Data
public class DocumentHistorySearchDto {
  // 管理ID
  private String managementId;
  // 書類ID
  private String documentId;
  // 作成日
  private String createDate;
  // 書類名
  private String documentName;
  // 申請者名
  private String applicantName;
  // 進捗ステータス
  private String progressStatus;
}