package com.highjunk.document.service.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.highjunk.document.dto.MyUser;
import com.highjunk.document.entity.UserInfoEntity;
import com.highjunk.document.repository.UserInfoMapper;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

  @Autowired
  private UserInfoMapper userInfoMapper;

  @Override
  public UserDetails loadUserByUsername(String loginId) throws UsernameNotFoundException {

    UserInfoEntity user = userInfoMapper.findById(loginId);
    
    MyUser myUser = new MyUser();
    myUser.setUsername(user.getEmployeeId());
    myUser.setPassword(user.getPassword());

    return myUser;
  }
}
