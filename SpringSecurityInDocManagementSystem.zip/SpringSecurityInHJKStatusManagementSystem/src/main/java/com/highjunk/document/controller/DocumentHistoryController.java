package com.highjunk.document.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.highjunk.document.dto.DocumentHistoryDetailDto;
import com.highjunk.document.dto.DocumentHistorySearchDto;
import com.highjunk.document.form.DocumentHistoryDetailForm;
import com.highjunk.document.form.DocumentHistorySearchForm;
import com.highjunk.document.service.DocumentHistoryService;

/**
 * 履歴取得コントローラー
 * @author HighJunk
 *
 */
@RestController
@RequestMapping(value="/history")
public class DocumentHistoryController {
  // 書類履歴サービス実装クラス
  @Autowired
  private DocumentHistoryService documentHistoryService;

  /**
   * 書類詳細履歴取得
   * @param form DocumentHistoryDetailForm
   * @return DocumentHistoryDetailDto
   */
  @PostMapping(value="/detail")
  public ResponseEntity<DocumentHistoryDetailDto> getDetail(@RequestBody DocumentHistoryDetailForm form) {
    DocumentHistoryDetailDto documentHistoryDetailDto = documentHistoryService.getDetail(form);
    return ResponseEntity.ok(documentHistoryDetailDto);
    // 例外クラス作りたい
  }

  /**
   * 書類履歴検索
   * @param form DocumentHistorySearchForm
   * @return List<DocumentHistorySearchDto>
   */
  @PostMapping(value="/search")
  public ResponseEntity<List<DocumentHistorySearchDto>> search(@RequestBody DocumentHistorySearchForm form) {
    List<DocumentHistorySearchDto> documentHistorySearchDtoList = documentHistoryService.searchDocumentHistory(form);
    return ResponseEntity.ok(documentHistorySearchDtoList);
  }
}