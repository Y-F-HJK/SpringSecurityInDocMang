package com.highjunk.document.form;

import lombok.Data;

/**
 * 昇格申請書タスク詳細フォーム
 * @author HighJunk
 *
 */
@Data
public class PromotionRequestTaskForm {
  // 管理ID
  private int managementId;
}