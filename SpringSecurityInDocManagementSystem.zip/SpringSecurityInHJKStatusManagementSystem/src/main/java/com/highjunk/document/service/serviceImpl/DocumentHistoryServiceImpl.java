package com.highjunk.document.service.serviceImpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.highjunk.document.common.ClassificationCodeEnum;
import com.highjunk.document.common.ProgressStatusEnum;
import com.highjunk.document.common.WorkContentEnum;
import com.highjunk.document.dto.DocumentActionHistoryDto;
import com.highjunk.document.dto.DocumentHistoryDetailDto;
import com.highjunk.document.dto.DocumentHistoryDto;
import com.highjunk.document.dto.DocumentHistorySearchDto;
import com.highjunk.document.dto.DocumentKeyDto;
import com.highjunk.document.entity.DocumentHistoryEntity;
import com.highjunk.document.entity.PromotionRequestEntity;
import com.highjunk.document.form.DocumentHistoryDetailForm;
import com.highjunk.document.form.DocumentHistorySearchForm;
import com.highjunk.document.repository.CodeMapper;
import com.highjunk.document.repository.CompletedDocumentManagementMapper;
import com.highjunk.document.repository.DocumentHistoryMapper;
import com.highjunk.document.repository.EmployeeMasterMapper;
import com.highjunk.document.repository.PromotionRequestMapper;
import com.highjunk.document.service.DocumentHistoryService;

/**
 * 書類履歴サービス実装クラス
 * @author HighJunk
 *
 */
@Service
public class DocumentHistoryServiceImpl implements DocumentHistoryService {

  // 書類履歴テーブルリポジトリ
  @Autowired
  private DocumentHistoryMapper documentHistoryMapper;

  // 昇格申請書テーブルリポジトリ
  @Autowired
  private PromotionRequestMapper promotionRequestMapper;

  // 社員マスタリポジトリ
  @Autowired
  private EmployeeMasterMapper employeeMasterMapper;

  // コードテーブルリポジトリ
  @Autowired
  private CodeMapper codeMapper;

  // 完了済書類管理テーブルリポジトリ
  @Autowired
  private CompletedDocumentManagementMapper completedDocumentManagementMapper;

  // 日付フォーマット
  SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

  /**
   * 昇格申請書履歴詳細取得
   * @param DocumentHistoryDetailForm 昇格申請書履歴一覧詳細取得フォーム
   * @return DocumentHistoryDetailDto 書類詳細クラスDto
   */
  @Override
  public DocumentHistoryDetailDto getDetail(DocumentHistoryDetailForm form) {
    // 昇格申請書を取得
    PromotionRequestEntity promotionRequestEntity = promotionRequestMapper.findByManagementId(Integer.parseInt(form.getManagementId()));

    // 書類履歴を取得
    List<DocumentHistoryDto> documentHistoryList = documentHistoryMapper.getDocumentHistory(
        Integer.parseInt(form.getManagementId()), form.getDocumentId());

    // 返却用listに変換
    List<DocumentActionHistoryDto> documentActionHistoryList =
      documentHistoryList.stream()
        .map(e -> convertToActionHistoryList(e))
        .collect(Collectors.toList());

    // 返却用dto生成
    DocumentHistoryDetailDto documentHistoryDetailDto = new DocumentHistoryDetailDto();

    // dtoに値をset
    documentHistoryDetailDto.setCreateDate(promotionRequestEntity.getCreateDate() != null ? sdf.format(promotionRequestEntity.getCreateDate()) : "");
    documentHistoryDetailDto.setCompleteDate(promotionRequestEntity.getApprovalDate() != null ? sdf.format(promotionRequestEntity.getApprovalDate()) : "");
    documentHistoryDetailDto.setApplicantComment(promotionRequestEntity.getApplicantComment());
    documentHistoryDetailDto.setTargetComment(promotionRequestEntity.getTargetComment() != null ? promotionRequestEntity.getTargetComment() : "");
    documentHistoryDetailDto.setOfficerComment1(promotionRequestEntity.getOfficerComment1() != null ? promotionRequestEntity.getOfficerComment1() :"");
    documentHistoryDetailDto.setOfficerComment2(promotionRequestEntity.getOfficerComment2() != null ? promotionRequestEntity.getOfficerComment2() : "");
    documentHistoryDetailDto.setOfficerComment3(promotionRequestEntity.getOfficerComment3() != null ? promotionRequestEntity.getOfficerComment3() : "");
    documentHistoryDetailDto.setDocumentActionHistoryList(documentActionHistoryList);

    // 返却
    return documentHistoryDetailDto;
  }

  /**
   * 返却用Dtoに変換
   * @param documentHistoryDto 書類履歴Dto
   * @return DocumentActionHistoryDto 行動履歴Dto
   */
  private DocumentActionHistoryDto convertToActionHistoryList(DocumentHistoryDto documentHistoryDto) {
    // 返却用インスタンス生成
    DocumentActionHistoryDto documentActionHistoryDto = new DocumentActionHistoryDto();

    // 実行日set
    documentActionHistoryDto.setActionDay(documentHistoryDto.getCreateDate() != null ? sdf.format(documentHistoryDto.getCreateDate()) : "");

    // 行動者名set
    if(StringUtils.isNotBlank(documentHistoryDto.getEmployeeId())) {
      // 社員名取得
      String employeeName = employeeMasterMapper.getEmployeeName(documentHistoryDto.getEmployeeId());
      documentActionHistoryDto.setActionUserName(employeeName != null ? employeeName : "");
    } else {
      documentActionHistoryDto.setActionUserName("");
    }

    // 実行内容set
    if(StringUtils.isNotBlank(documentHistoryDto.getProgressStatus())) {
      // 実行内容取得してset
      documentActionHistoryDto.setActionContent(WorkContentEnum.getWorkContent(documentHistoryDto.getProgressStatus()));
    }

    // 返却
    return documentActionHistoryDto;
  }

  /**
   * 書類履歴検索
   * @param DocumentHistorySearchForm 書類履歴取得検索フォーム
   * @return List<DocumentHistorySearchDto> 書類履歴リスト
   */
  @Override
  public List<DocumentHistorySearchDto> searchDocumentHistory(DocumentHistorySearchForm form) {
    // 返却用
    List<DocumentHistorySearchDto> documentHistorySearchDtoList = new ArrayList<DocumentHistorySearchDto>();

    // 検索パラメータ生成
    String documentId = form.getDocumentId() != null ? form.getDocumentId() : "";
    String userId = form.getUserId() != null ? form.getUserId() : "";
    boolean appFlg = form.getAppFlg() != null ? form.getAppFlg() : false;
    boolean completedFlg = form.getCompletedFlg() != null ? form.getCompletedFlg() : false;
    boolean denialFlg = form.getDenialFlg() != null ? form.getDenialFlg() : false;

    // 書類履歴取得
    List<DocumentHistoryEntity> documentHistoryList =
      documentHistoryMapper.searchDocumentHistory(documentId, userId, appFlg, completedFlg, denialFlg);

    // グルーピング用複合キー作成(書類ID,管理ID)
    Function<DocumentHistoryEntity, String> compositeKey = e -> {
      StringBuffer sb = new StringBuffer();
      sb.append(e.getDocumentId()).append("-").append(e.getManagementId());
      return sb.toString();
    };

    if(!CollectionUtils.isEmpty(documentHistoryList)) {
      // 管理IDと書類IDでグルーピング
      // グルーピング後、管理IDと書類IDを取得
      Map<String, List<DocumentHistoryEntity>> documentHistoryMap = 
          documentHistoryList.stream().collect(Collectors.groupingBy(compositeKey));

      // mapのkeyを分解してlistに格納
      for(Map.Entry<String, List<DocumentHistoryEntity>> map : documentHistoryMap.entrySet()) {
        // 返却用
        DocumentHistorySearchDto documentHistorySearchDto = new DocumentHistorySearchDto();

        // key取得
        String key = map.getKey();
        // key分解
        String[] keyArray = key.split("-");

        // 管理ID,書類IDを返却用DTOにset
        documentHistorySearchDto.setDocumentId(keyArray[0]);
        documentHistorySearchDto.setManagementId(keyArray[1]);

        // 日付でsortして最新の履歴レコードを取得
        Optional<DocumentHistoryEntity> documentHistoryEntityOpt =
          map.getValue().stream()
            .sorted(Comparator.comparing(DocumentHistoryEntity::getCreateDate).reversed())
            .findFirst();

        // 存在するとき
        if(documentHistoryEntityOpt.isPresent()) {
          DocumentHistoryEntity documentHistoryEntity = documentHistoryEntityOpt.get();

          // 申請中のレコードが完了 or 否認されているものだったら返却リストから除外する
          if(!ProgressStatusEnum.PRESIDENTAPPROVED.getProgressStatus().equals(documentHistoryEntity.getProgressStatus()) && !ProgressStatusEnum.DENIAL.getProgressStatus().equals(documentHistoryEntity.getProgressStatus())) {
            // 完了済みテーブルに登録されている書類かどうか判定
            DocumentKeyDto documentKeyDto = completedDocumentManagementMapper.getKey(documentHistoryEntity.getManagementId(), documentHistoryEntity.getEmployeeId());
            if(!ObjectUtils.isEmpty(documentKeyDto)) {
              // 完了 or 否認があるときは
              continue;
            }
          }

          // 作成日を返却用DTOにset
          documentHistorySearchDto.setCreateDate(documentHistoryEntity.getCreateDate() != null ? sdf.format(documentHistoryEntity.getCreateDate()) : null);
          // 進捗ステータスをDTOにset
          String progressStatusContent =
              codeMapper.getProgressStatusContent(ClassificationCodeEnum.PROGRESS.getClassificationCode(), documentHistoryEntity.getProgressStatus());
          documentHistorySearchDto.setProgressStatus(progressStatusContent != null ? progressStatusContent : "");
        }

        // 書類名を取得し返却用Dtoにset
        String documentName =
            codeMapper.getProgressStatusContent(ClassificationCodeEnum.DOCUMENT.getClassificationCode(), keyArray[0]);
        documentHistorySearchDto.setDocumentName(documentName != null ? documentName : "");

        // 書類IDが001で昇格申請書のデータ取得
        if("001".equals(keyArray[0])) {
          // 昇格申請書のレコード取得
          PromotionRequestEntity promotionRequestEntity = promotionRequestMapper.findByManagementId(Integer.parseInt(keyArray[1]));
          // 申請者名
          String applicantName = "";

          if(!ObjectUtils.isEmpty(promotionRequestEntity)) {
            // 申請者IDを取得
            String aplicantId = promotionRequestEntity.getApplicantEmployeeId();
            // 申請者名取得
            applicantName = employeeMasterMapper.getEmployeeName(aplicantId) != null ? employeeMasterMapper.getEmployeeName(aplicantId) : "";
          }
          // dtoにset
          documentHistorySearchDto.setApplicantName(applicantName);
        }

        // 返却用listにDtoをset
        documentHistorySearchDtoList.add(documentHistorySearchDto);

      }
    }

    // list返却
    return documentHistorySearchDtoList;
  }

}