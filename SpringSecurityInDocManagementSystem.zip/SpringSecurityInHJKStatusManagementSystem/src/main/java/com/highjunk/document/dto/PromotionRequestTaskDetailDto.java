package com.highjunk.document.dto;

import lombok.Data;

/**
 * タスク詳細DTO
 * 
 * @author HighJunk
 *
 */
@Data
public class PromotionRequestTaskDetailDto {

  // 申請者コメント
  private String applicantComment;
  // 昇格対象者コメント
  private String targetComment;
  // 評価者コメント1
  private String officerComment1;
  // 評価者コメント2
  private String officerComment2;
  // 進捗ステータス
  private String progressStatus;
}