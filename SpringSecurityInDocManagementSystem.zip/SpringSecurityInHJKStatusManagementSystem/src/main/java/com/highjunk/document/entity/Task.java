package com.highjunk.document.entity;

/**
 * タスククラス
 * @author jkawa
 */
public class Task {
  
  private String managementId; // 管理ID
  private String documentId; // 書類ID
  private String targetName; // 書類対象者
  private String applicantName; // 申請者名
  private String documentName; // 書類名
  private String applicantDay; // 申請日
  private String progressStatus; // 進捗ステータス
  private String workContent; // 作業内容
  private String requester; // 作業依頼者
  private String requestDay; // 作業日

  /**
   * コンストラクタ
   * @param managementId　// 管理ID
   * @param documentId // 書類ID
   * @param targetName // 書類対象者
   * @param applicantName // 申請者名
   * @param documentName // 書類名
   * @param applicantDay // 申請日
   * @param progressStatus // 進捗ステータス
   * @param workContent // 作業内容
   * @param requester // 作業依頼者
   * @param requestDay // 作業日
   */
  public Task(String managementId, String documentId, String targetName, String applicantName, String documentName, String applicantDay, String progressStatus, String workContent, String requester, String requestDay) {
    this.managementId = managementId;
    this.documentId = documentId;
    this.targetName = targetName;
    this.applicantName = applicantName;
    this.documentName = documentName;
    this.applicantDay = applicantDay;
    this.progressStatus = progressStatus;
    this.workContent = workContent;
    this.requester = requester;
    this.requestDay = requestDay;
  }

  public String getManagementId() {
    return managementId;
  }

  public void setManagementId(String managementId) {
    this.managementId = managementId;
  }

  public String getDocumentId() {
    return documentId;
  }

  public void setDocumentId(String documentId) {
    this.documentId = documentId;
  }

  public String getTargetName() {
    return targetName;
  }

  public void setTargetName(String targetName) {
    this.targetName = targetName;
  }

  public String getApplicantName() {
    return applicantName;
  }

  public void setApplicantName(String applicantName) {
    this.applicantName = applicantName;
  }

  public String getDocumentName() {
    return documentName;
  }

  public void setDocumentName(String documentName) {
    this.documentName = documentName;
  }

  public String getApplicantDay() {
    return applicantDay;
  }

  public void setApplicantDay(String applicantDay) {
    this.applicantDay = applicantDay;
  }

  public String getProgressStatus() {
    return progressStatus;
  }

  public void setProgressStatus(String progressStatus) {
    this.progressStatus = progressStatus;
  }

  public String getWorkContent() {
    return workContent;
  }

  public void setWorkContent(String workContent) {
    this.workContent = workContent;
  }

  public String getRequester() {
    return requester;
  }

  public void setRequester(String requester) {
    this.requester = requester;
  }

  public String getRequestDay() {
    return requestDay;
  }

  public void setRequestDay(String requestDay) {
    this.requestDay = requestDay;
  }
  
  

}
