package com.highjunk.document.repository;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.highjunk.document.dto.DocumentKeyDto;
import com.highjunk.document.entity.CompletedDocumentManagementEntity;
/**
 * 完了済書類管理 Mapper
 * @author HighJunk
 *
 */
@Mapper
public interface CompletedDocumentManagementMapper {
  
  //履歴一覧テーブルへインサート
  @Insert("insert into completed_document_management (management_id, document_id,progress_status)"
  		+ "values (#{managementId}, #{documentId}, #{progressStatus})")
   void insert(CompletedDocumentManagementEntity CDME);

  // 書類履歴エンティティの取得(新規作成時)
  @Select ("select * from document_history where management_id = #{managementId} and document_id = #{documentId} and progress_status = #{progressStatus}")
  CompletedDocumentManagementEntity findByNewManagementIdAndDocumentId(Integer managementId, String documentId, String progressStatus);

  /**
   * 完了or否認されている書類のkeyを取得
   * @param managementId 管理id
   * @param documentId 書類id
   * @return DocumentKeyDto 書類のkey情報
   */
  DocumentKeyDto getKey(int managementId, String documentId);
}
