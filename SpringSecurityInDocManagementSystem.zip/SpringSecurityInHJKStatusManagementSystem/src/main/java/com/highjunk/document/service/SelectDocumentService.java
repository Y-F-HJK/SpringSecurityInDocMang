package com.highjunk.document.service;

import java.util.List;

/**
 * 書類選択サービス
 * @author HighJunk
 *
 */
import com.highjunk.document.dto.DocumentDto;
import com.highjunk.document.dto.EmployeeMasterDto;
import com.highjunk.document.dto.PositionDto;

public interface SelectDocumentService {

  /**
   * プルダウン生成用書類リストの作成
   * @return 書類リスト
   */
  public List<DocumentDto> createDocumentList();

  /**
   * プルダウン生成用役職リストの作成
   * @return 役職リスト
   */
  public List<PositionDto> createPositionList();

  /**
   * プルダウン生成用社員リストの作成
   * @return 社員リスト
   */
  public List<EmployeeMasterDto> createEmployeeList();
}
