package com.highjunk.document.service.serviceImpl;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.highjunk.document.common.ClassificationCodeEnum;
import com.highjunk.document.common.PositionEnum;
import com.highjunk.document.dto.PromotionRequestTaskDetailDto;
import com.highjunk.document.entity.CodeEntity;
import com.highjunk.document.entity.CompletedDocumentManagementEntity;
import com.highjunk.document.entity.DocumentHistoryEntity;
import com.highjunk.document.entity.DocumentProgressManagementEntity;
import com.highjunk.document.entity.EmployeeMasterEntity;
import com.highjunk.document.entity.PromotionRequestEntity;
import com.highjunk.document.form.TaskCommentForm;
import com.highjunk.document.repository.CodeMapper;
import com.highjunk.document.repository.CompletedDocumentManagementMapper;
import com.highjunk.document.repository.DocumentHistoryMapper;
import com.highjunk.document.repository.DocumentProgressManagementMapper;
import com.highjunk.document.repository.EmployeeMasterMapper;
import com.highjunk.document.repository.PromotionRequestMapper;
import com.highjunk.document.service.PromotionRequestTaskService;

/**
 * タスク詳細情報取得サービス
 *
 * @author HighJunk
 *
 */
@Service
public class PromotionRequestTaskServiceImpl implements PromotionRequestTaskService {

  // 昇格申請書 Mapper
  @Autowired
  public PromotionRequestMapper promotionRequestMapper;

  // 書類進捗管理 Mapper
  @Autowired
  public DocumentProgressManagementMapper documentProgressManagementMapper;

  // 書類履歴 Mapper
  @Autowired
  public DocumentHistoryMapper documentHistoryMapper;

  // 完了済書類管理Mapper
  @Autowired
  public CompletedDocumentManagementMapper completedDocumentManagementMapper;

  // 社員マスタMapper
  @Autowired
  public EmployeeMasterMapper employeeMasterMapper;

  // コードマスタMapper
  @Autowired
  public CodeMapper codeMapper;

  /**
   * タスク詳細情報取得
   * 
   * @param manegementId 管理ID
   * @return タスク詳細情報の取得
   */
  public PromotionRequestTaskDetailDto getTaskDetail(String managementId) {

    // 昇格申請書類の取得
    PromotionRequestEntity prEntity = promotionRequestMapper.findByManagementId(Integer.valueOf(managementId));

    // 進捗管理テーブルから進捗ステータスの取得
    DocumentProgressManagementEntity documentProgressManagemententity = documentProgressManagementMapper
        .findByManagementIdAndDocumentId(Integer.valueOf(managementId), "001");

    // 返却用タスク詳細情報Dto
    PromotionRequestTaskDetailDto prTaskDetail = new PromotionRequestTaskDetailDto();

    // 申請者コメント
    prTaskDetail.setApplicantComment(prEntity.getApplicantComment());
    // 昇格対象者コメント
    prTaskDetail.setTargetComment(prEntity.getTargetComment());
    // 評価者コメント1
    prTaskDetail.setOfficerComment1(prEntity.getOfficerComment1());
    // 評価者コメント2
    prTaskDetail.setOfficerComment2(prEntity.getOfficerComment2());
    // 進捗ステータス
    prTaskDetail.setProgressStatus(documentProgressManagemententity.getProgressStatus());
    // 返却
    return prTaskDetail;
  }

  /**
   * タスク情報更新
   * 
   * @param form タスクコメントフォーム
   * @return 真偽
   * @throws IOException
   */
  public boolean updatePromotionRequest(TaskCommentForm form) throws IOException {

    // 対象レコードの取得
    PromotionRequestEntity prEntity = promotionRequestMapper.findByManagementId(form.getManagementId());

    // 進捗ステータスが020の場合
    if (form.getProgressStatus().equals("020")) {

      // 更新日時
      Date nowDate = new Date();

      // 進捗ステータスを上司承認待ちに変更@進捗管理テーブル
      documentProgressManagementMapper.updateProgressStatus(form.getProgressStatus(), form.getManagementId());

      // 次の作業者の変更@進捗管理テーブル
      documentProgressManagementMapper.updateEmployeeId(prEntity.getApplicantEmployeeId(), form.getManagementId());

      // 更新日の更新@進捗管理テーブル
      documentProgressManagementMapper.updateUpdateDate(nowDate, form.getManagementId());

      // 対象者コメントの更新@昇格申請書類テーブル
      promotionRequestMapper.updateTargetComment(form.getComment(), form.getManagementId());

      // 更新日の更新@昇格申請書類テーブル
      promotionRequestMapper.updateUpdateDate(nowDate, form.getManagementId());

      // 履歴管理テーブルへインサート
      // 書類履歴エンティティの生成
      DocumentHistoryEntity documentHistoryEntity = createDocumentHistoryEntity(form.getManagementId(),
          form.getUserId(), form.getProgressStatus(), nowDate);

      // インサート処理
      documentHistoryMapper.insert(documentHistoryEntity);

      // 処理終了確認のため書類履歴テーブルより先ほどインサートしたレコードを取得
      DocumentHistoryEntity documentHistoryEntityCheck =
          documentHistoryMapper.getOneDocumentHistory(form.getManagementId(), documentHistoryEntity.getDocumentId());

      // インスタンス存在チェック
      if (documentHistoryEntityCheck == null) {
        // エクセプションを発生させる
        System.out.println("エクセプションを発生させる");
      }

      // 進捗ステータスが100の場合
    } else if (form.getProgressStatus().equals("100")) {

      // 更新日時
      Date nowDate = new Date();

      // 進捗ステータスを役員承認待ち(川口さん)に変更@進捗管理テーブル
      documentProgressManagementMapper.updateProgressStatus(form.getProgressStatus(), form.getManagementId());

      // 次の作業者の変更@進捗管理テーブル
      documentProgressManagementMapper.updateEmployeeId(PositionEnum.KAWAGUCHI.getId(), form.getManagementId());

      // 更新日の更新@進捗管理テーブル
      documentProgressManagementMapper.updateUpdateDate(nowDate, form.getManagementId());

      // 履歴管理テーブルへインサート
      // 書類履歴エンティティの生成
      DocumentHistoryEntity documentHistoryEntity = createDocumentHistoryEntity(form.getManagementId(),
          form.getUserId(), form.getProgressStatus(), nowDate);

      // インサート処理
      documentHistoryMapper.insert(documentHistoryEntity);

      // 処理終了確認のため書類履歴テーブルより先ほどインサートしたレコードを取得
      DocumentHistoryEntity documentHistoryEntityCheck =
          documentHistoryMapper.getOneDocumentHistory(form.getManagementId(), documentHistoryEntity.getDocumentId());

      // インスタンス存在チェック
      if (documentHistoryEntityCheck == null) {
        // エクセプションを発生させる
        System.out.println("エクセプションを発生させる");
      }
      // 進捗ステータスが200の場合
    } else if (form.getProgressStatus().equals("200")) {

      // 更新日時
      Date nowDate = new Date();

      // 進捗ステータスを役員承認待ち(中村さん)に変更@進捗管理テーブル
      documentProgressManagementMapper.updateProgressStatus(form.getProgressStatus(), form.getManagementId());

      // 次の作業者の変更@進捗管理テーブル
      documentProgressManagementMapper.updateEmployeeId(PositionEnum.NAKAMURA.getId(), form.getManagementId());

      // 更新日の更新@進捗管理テーブル
      documentProgressManagementMapper.updateUpdateDate(nowDate, form.getManagementId());

      // 対象者コメントの更新@昇格申請書類テーブル
      promotionRequestMapper.updateOfficerComment1(form.getComment(), form.getManagementId());

      // 更新日の更新@昇格申請書類テーブル
      promotionRequestMapper.updateUpdateDate(nowDate, form.getManagementId());

      // 履歴管理テーブルへインサート
      // 書類履歴エンティティの生成
      DocumentHistoryEntity documentHistoryEntity = createDocumentHistoryEntity(form.getManagementId(),
          form.getUserId(), form.getProgressStatus(), nowDate);

      // インサート処理
      documentHistoryMapper.insert(documentHistoryEntity);

      // 処理終了確認のため書類履歴テーブルより先ほどインサートしたレコードを取得
      DocumentHistoryEntity documentHistoryEntityCheck =
          documentHistoryMapper.getOneDocumentHistory(form.getManagementId(), documentHistoryEntity.getDocumentId());

      // インスタンス存在チェック
      if (documentHistoryEntityCheck == null) {
        // エクセプションを発生させる
        System.out.println("エクセプションを発生させる");
      }

      // 進捗ステータスが300の場合
    } else if (form.getProgressStatus().equals("300")) {
      // 更新日時
      Date nowDate = new Date();

      // 進捗ステータスを役員承認待ち(寺脇社長)に変更@進捗管理テーブル
      documentProgressManagementMapper.updateProgressStatus(form.getProgressStatus(), form.getManagementId());

      // 次の作業者の変更@進捗管理テーブル
      documentProgressManagementMapper.updateEmployeeId(PositionEnum.TERAWAKI.getId(), form.getManagementId());

      // 更新日の更新@進捗管理テーブル
      documentProgressManagementMapper.updateUpdateDate(nowDate, form.getManagementId());

      // 対象者コメントの更新@昇格申請書類テーブル
      promotionRequestMapper.updateOfficerComment2(form.getComment(), form.getManagementId());

      // 更新日の更新@昇格申請書類テーブル
      promotionRequestMapper.updateUpdateDate(nowDate, form.getManagementId());

      // 履歴管理テーブルへインサート
      // 書類履歴エンティティの生成
      DocumentHistoryEntity documentHistoryEntity = createDocumentHistoryEntity(form.getManagementId(),
          form.getUserId(), form.getProgressStatus(), nowDate);

      // インサート処理
      documentHistoryMapper.insert(documentHistoryEntity);

      // 処理終了確認のため書類履歴テーブルより先ほどインサートしたレコードを取得
      DocumentHistoryEntity documentHistoryEntityCheck =
          documentHistoryMapper.getOneDocumentHistory(form.getManagementId(), documentHistoryEntity.getDocumentId());

      // インスタンス存在チェック
      if (documentHistoryEntityCheck == null) {
        // エクセプションを発生させる
        System.out.println("エクセプションを発生させる");
      }

      // 進捗ステータスが400の場合
    } else if (form.getProgressStatus().equals("400")) {

      // 更新日時
      Date nowDate = new Date();

      // 対象者コメントの更新@昇格申請書類テーブル
      promotionRequestMapper.updateOfficerComment3(form.getComment(), form.getManagementId());

      // 更新日の更新@昇格申請書類テーブル
      promotionRequestMapper.updateUpdateDate(nowDate, form.getManagementId());

      // 承認日の更新@昇格申請書類テーブル
      promotionRequestMapper.updateApprovalDate(nowDate, form.getManagementId());

      // 履歴管理テーブルへインサート
      // 書類履歴エンティティの生成
      DocumentHistoryEntity documentHistoryEntity = createDocumentHistoryEntity(form.getManagementId(),
          form.getUserId(), form.getProgressStatus(), nowDate);

      // インサート処理
      documentHistoryMapper.insert(documentHistoryEntity);

      // 進捗管理テーブルから該当タスクを削除
      documentProgressManagementMapper.delete(form.getManagementId());

      // 完了済書類管理テーブルへインサート
      // 完了済書類管理エンティティの生成
      CompletedDocumentManagementEntity completedDocumentManagementEntity = new CompletedDocumentManagementEntity();

      // 完了済書類管理エンティティに値をset
      completedDocumentManagementEntity.setManagementId(form.getManagementId());
      completedDocumentManagementEntity.setDocumentId("001");
      completedDocumentManagementEntity.setProgressStatus(form.getProgressStatus());

      // インサート処理
      completedDocumentManagementMapper.insert(completedDocumentManagementEntity);

      // 処理終了確認のため完了済書類管理テーブルより先ほどインサートしたレコードを取得
      CompletedDocumentManagementEntity completedDocumentManagementEntityCheck = completedDocumentManagementMapper
          .findByNewManagementIdAndDocumentId(form.getManagementId(), documentHistoryEntity.getDocumentId(),
              documentHistoryEntity.getProgressStatus());

      // インスタンス存在チェック
      if (completedDocumentManagementEntityCheck != null) {
        // エクセプションを発生させる
        System.out.println("エクセプションを発生させる");
      }

      // ファイル出力メソッド呼出
      createExcel(prEntity);

      // 進捗ステータスが999の場合
    } else if (form.getProgressStatus().equals("999")) {

      // 更新日時
      Date nowDate = new Date();

      // 対象者コメントの更新@昇格申請書類テーブル
      promotionRequestMapper.updateOfficerComment3(form.getComment(), form.getManagementId());

      // 更新日の更新@昇格申請書類テーブル
      promotionRequestMapper.updateUpdateDate(nowDate, form.getManagementId());

      // 履歴管理テーブルへインサート
      // 書類履歴エンティティの生成
      DocumentHistoryEntity documentHistoryEntity = createDocumentHistoryEntity(form.getManagementId(),
          form.getUserId(), form.getProgressStatus(), nowDate);

      // インサート処理
      documentHistoryMapper.insert(documentHistoryEntity);

      // 進捗管理テーブルから該当タスクを削除
      documentProgressManagementMapper.delete(form.getManagementId());

      // 完了済書類官僚テーブルへインサート
      // 完了済書類管理エンティティの生成
      CompletedDocumentManagementEntity completedDocumentManagementEntity = new CompletedDocumentManagementEntity();

      // 完了済書類管理エンティティに値をset
      completedDocumentManagementEntity.setManagementId(form.getManagementId());
      completedDocumentManagementEntity.setDocumentId("001");
      completedDocumentManagementEntity.setProgressStatus(form.getProgressStatus());

      // インサート処理
      completedDocumentManagementMapper.insert(completedDocumentManagementEntity);

      // 処理終了確認のため完了済書類管理テーブルより先ほどインサートしたレコードを取得
      CompletedDocumentManagementEntity completedDocumentManagementEntityCheck = completedDocumentManagementMapper
          .findByNewManagementIdAndDocumentId(form.getManagementId(), documentHistoryEntity.getDocumentId(),
              documentHistoryEntity.getProgressStatus());

      // インスタンス存在チェック
      if (completedDocumentManagementEntityCheck != null) {
        // エクセプションを発生させる
        System.out.println("エクセプションを発生させる");
      }
    }
    return true;
  }

  /**
   * 書類履歴エンティティの生成
   * 
   * @param managementId   管理ID
   * @param employeeId     社員ID
   * @param progressStatus 進捗ステータス
   * @param nowDate        現在日時
   * @return documentHistoryEntity 書類履歴エンティティ
   */
  public DocumentHistoryEntity createDocumentHistoryEntity(Integer managementId, String employeeId,
      String progressStatus, Date nowDate) {

    // 書類履歴エンティティの生成
    DocumentHistoryEntity documentHistoryEntity = new DocumentHistoryEntity();

    // 書類履歴エンティティに値をset
    documentHistoryEntity.setManagementId(managementId);
    documentHistoryEntity.setDocumentId("001");
    documentHistoryEntity.setEmployeeId(employeeId);
    documentHistoryEntity.setProgressStatus(progressStatus);
    documentHistoryEntity.setCreateDate(nowDate);

    return documentHistoryEntity;
  }

  /**
   * 出力ファイルの作成
   * 
   * @param prEntity 昇格申請書テーブルエンティティ
   * @throws IOException
   */
  public void createExcel(PromotionRequestEntity prEntity) throws IOException {

    // 社員情報（申請者）の取得
    EmployeeMasterEntity applicantEmployee = employeeMasterMapper.getEmployee(prEntity.getApplicantEmployeeId());

    // 社員情報（対象者）の取得
    EmployeeMasterEntity targetEmployee = employeeMasterMapper.getEmployee(prEntity.getTargetEmployeeId());

    // 部署名の取得
    CodeEntity applicant =
        codeMapper.getCode(ClassificationCodeEnum.DEPARTMENT.getClassificationCode(), applicantEmployee.getDepartmentId());

    // 昇格前役職情報の取得
    CodeEntity beforePosition =
        codeMapper.getCode(ClassificationCodeEnum.DEPARTMENT.getClassificationCode(), prEntity.getBeforePositionId());

    // 昇格後役職情報の取得
    CodeEntity afterPosition =
        codeMapper.getCode(ClassificationCodeEnum.DEPARTMENT.getClassificationCode(), prEntity.getAfterPositionId());

    // 日付フォーマット
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

    // ファイルパスの指定
    String excelName = "C:\\Users\\kkiba\\OneDrive\\デスクトップ\\申請書類ステータス管理システム\\fileTest\\" + sdf.format(new Date())
        + "_昇格申請書類_" + targetEmployee.getEmployeeName() + ".xlsx";

    // 昇格申請書類の読込
    Path p1 = Paths.get("C:\\Users\\kkiba\\OneDrive\\デスクトップ\\申請書類ステータス管理システム\\fileTest\\昇格申請書類フォーマット.xlsx");
    Path p2 = Paths.get(excelName);

    // 昇格申請書類フォーマットをコピー
    Files.copy(p1, p2);

    // 編集ファイルの取得
    FileInputStream inputExcel = new FileInputStream(excelName);

    // 編集ファイルへアクセス
    Workbook outputWorkbook = WorkbookFactory.create(inputExcel);

    // シートを指定
    outputWorkbook.setSheetName(0, targetEmployee.getEmployeeName() + "_昇格申請書類");
    Sheet outputSheet = outputWorkbook.getSheet(targetEmployee.getEmployeeName() + "_昇格申請書類");

    // 行を作成
    Row outputRow2 = outputSheet.getRow(2);
    Row outputRow3 = outputSheet.getRow(3);
    Row outputRow5 = outputSheet.getRow(5);
    Row outputRow6 = outputSheet.getRow(6);
    Row outputRow8 = outputSheet.getRow(8);
    Row outputRow9 = outputSheet.getRow(9);
    Row outputRow10 = outputSheet.getRow(10);
    Row outputRow12 = outputSheet.getRow(12);
    Row outputRow14 = outputSheet.getRow(14);
    Row outputRow16 = outputSheet.getRow(16);
    Row outputRow18 = outputSheet.getRow(18);
    Row outputRow20 = outputSheet.getRow(20);

    // セルを作成
    Cell cellCreateDate = outputRow2.getCell(7);
    Cell cellApprovalDate = outputRow3.getCell(7);
    Cell outputCell_age = outputRow5.getCell(1);
    Cell cellApplicantEmployeeName = outputRow6.getCell(1);
    Cell cellTargetEmployeeId = outputRow8.getCell(2);
    Cell cellBeforePosition = outputRow9.getCell(2);
    Cell cellAfterPositionId = outputRow10.getCell(2);
    Cell cellApplicantComment = outputRow12.getCell(0);
    Cell cellTargetComment = outputRow14.getCell(0);
    Cell cellOfficerComment1 = outputRow16.getCell(0);
    Cell cellOfficerComment2 = outputRow18.getCell(0);
    Cell cellOfficerComment3 = outputRow20.getCell(0);

    // 申請日
    cellCreateDate.setCellValue(sdf.format(prEntity.getCreateDate()));
    // 承認日
    cellApprovalDate.setCellValue(sdf.format(prEntity.getApprovalDate()));
    // 申請者所属
    outputCell_age.setCellValue(applicant.getCodeName());
    // 申請者名
    cellApplicantEmployeeName.setCellValue(applicantEmployee.getEmployeeName());
    // 昇格対象者名
    cellTargetEmployeeId.setCellValue(targetEmployee.getEmployeeName());
    // 現役職名
    cellBeforePosition.setCellValue(beforePosition.getCodeName());
    // 昇格役職名
    cellAfterPositionId.setCellValue(afterPosition.getCodeName());
    // 申請者コメント
    cellApplicantComment.setCellValue(prEntity.getApplicantComment());
    // 昇格対象者コメント
    cellTargetComment.setCellValue(prEntity.getTargetComment());
    // 評価者コメント（川口役員）
    cellOfficerComment1.setCellValue(prEntity.getOfficerComment1());
    // 評価者コメント（中村役員）
    cellOfficerComment2.setCellValue(prEntity.getOfficerComment2());
    // 評価者コメント（寺脇社長）
    cellOfficerComment3.setCellValue(prEntity.getOfficerComment3());

    // 出力用昇格申請書類フォーマット
    FileOutputStream outputExcel = new FileOutputStream(excelName);

    // ファイルへ出力
    outputWorkbook.write(outputExcel);

    // ストリームを閉じる
    inputExcel.close();
    outputExcel.close();

    // エクセルを閉じる
    outputWorkbook.close();

  }
}
