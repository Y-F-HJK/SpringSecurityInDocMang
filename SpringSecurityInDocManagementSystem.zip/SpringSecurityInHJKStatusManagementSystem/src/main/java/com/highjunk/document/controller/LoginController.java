package com.highjunk.document.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.highjunk.document.dto.MyUser;

/**
 * ログインコントローラー
 * @author HighJunk
 */
@Controller
public class LoginController {

  @GetMapping("/login")
  public String login() {
      return "login";
  }

  @GetMapping("/menu")
  public String hello(@AuthenticationPrincipal MyUser user, Model model) {

    model.addAttribute("userId", user.getUsername());

    return "menu";
  }

  @GetMapping("/timeout")
  public String timeout() {
    return "timeout";
  }
}