package com.highjunk.document.common;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;

/**
 * タスクの作業内容enum
 * @author HighJunk
 */
@Getter
public enum WorkContentEnum {

  /** 作成 */
  CREATE("作成"),
  /** コメント */
  COMMENT("コメント"),
  /** 承認 */
  APPROVAL("承認"),
  /** 否認 */
  DENIAL("否認");

  // 作業内容
  private final String workContent;

  /**
   * コンストラクタ
   * @param workContent 作業内容
   */
  private WorkContentEnum(String workContent) {
    this.workContent = workContent;
  }

  /**
   * 進捗ステータスに対する作業内容を格納するmap生成
   * @param なし
   * @return Map<String, String> key: 進捗ステータス value: 作業内容
   */
  private static Map<String, String> getMap() {
    // 返却用map生成
    Map<String, String> workContentMap = new HashMap<String, String>();

    // mapに進捗ステータスと作業内容set
    // key: 進捗ステータス value: 作業内容
    workContentMap.put(ProgressStatusEnum.CREATE.getProgressStatus(), WorkContentEnum.CREATE.getWorkContent());
    workContentMap.put(ProgressStatusEnum.APPLIED.getProgressStatus(), WorkContentEnum.CREATE.getWorkContent());
    workContentMap.put(ProgressStatusEnum.COMMENTED.getProgressStatus(), WorkContentEnum.COMMENT.getWorkContent());
    workContentMap.put(ProgressStatusEnum.BOSSAPPROVED.getProgressStatus(), WorkContentEnum.APPROVAL.getWorkContent());
    workContentMap.put(ProgressStatusEnum.EXECUTIVEAPPROVED1.getProgressStatus(), WorkContentEnum.APPROVAL.getWorkContent());
    workContentMap.put(ProgressStatusEnum.EXECUTIVEAPPROVED2.getProgressStatus(), WorkContentEnum.APPROVAL.getWorkContent());
    workContentMap.put(ProgressStatusEnum.DENIAL.getProgressStatus(), WorkContentEnum.DENIAL.getWorkContent());

    // map返却
    return workContentMap;
  }

  /**
   * 作業内容取得
   * @param progressStatus 進捗ステータス
   * @return String 作業内容
   */
  public static String getWorkContent(String progressStatus) {
    // 返却用
    String workContent = "";

    // 作業内容を格納したmapを取得
    Map<String, String> workContentMap = getMap();

    // mapから作業内容を取得
    if(workContentMap.containsKey(progressStatus)) {
      workContent = workContentMap.get(progressStatus);
    }

    // 作業内容返却
    return workContent;
  }

}