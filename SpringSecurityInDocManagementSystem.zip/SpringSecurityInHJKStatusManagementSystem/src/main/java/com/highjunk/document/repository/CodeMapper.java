package com.highjunk.document.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.highjunk.document.entity.CodeEntity;

/**
 * コード Mapper
 * @author HighJunk
 */
@Mapper
public interface CodeMapper {

  // コード情報一覧取得
  List<CodeEntity> getCodeList(String classificationCode);

  // コード情報取得
  CodeEntity getCode(@Param("classificationCode") String classificationCode, @Param("code") String code);

  // コード名取得
  String getProgressStatusContent(@Param("classificationCode") String classificationCode, @Param("code") String code);

}