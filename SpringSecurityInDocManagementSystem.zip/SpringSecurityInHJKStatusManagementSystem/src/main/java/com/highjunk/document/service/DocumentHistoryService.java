package com.highjunk.document.service;

import java.util.List;

import com.highjunk.document.dto.DocumentHistoryDetailDto;
import com.highjunk.document.dto.DocumentHistorySearchDto;
import com.highjunk.document.form.DocumentHistoryDetailForm;
import com.highjunk.document.form.DocumentHistorySearchForm;

/**
 * 書類履歴サービス
 * @author HighJunk
 *
 */
public interface DocumentHistoryService {
  /**
   * 書類詳細取得
   * @param form DocumentHistoryDetailForm
   * @return DocumentHistoryDetailDto
   */
  public DocumentHistoryDetailDto getDetail(DocumentHistoryDetailForm form);

  /**
   * 書類履歴検索
   * @param form DocumentHistorySearchForm
   * @return List<DocumentHistorySearchDto>
   */
  public List<DocumentHistorySearchDto> searchDocumentHistory(DocumentHistorySearchForm form);
}