package com.highjunk.document.service.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.highjunk.document.common.ClassificationCodeEnum;
import com.highjunk.document.dto.DocumentDto;
import com.highjunk.document.dto.EmployeeMasterDto;
import com.highjunk.document.dto.PositionDto;
import com.highjunk.document.entity.CodeEntity;
import com.highjunk.document.repository.CodeMapper;
import com.highjunk.document.repository.EmployeeMasterMapper;
import com.highjunk.document.service.SelectDocumentService;

/**
 * 書類選択サービス
 * @author HighJunk
 */
@Service
public class SelectDocumentServiceImpl implements SelectDocumentService {

  @Autowired
  private CodeMapper codeMapper;

  @Autowired
  private EmployeeMasterMapper employeeMasterMapper;

  /**
   * プルダウン生成用書類リストの作成
   * @return 書類リスト
   */
  public List<DocumentDto> createDocumentList() {

    // データベースより書類のみのリスト(書類リスト)を取得
    List<CodeEntity> docList = codeMapper.getCodeList(ClassificationCodeEnum.DOCUMENT.getClassificationCode());

    // 返却用書類リスト
    List<DocumentDto> documentList = new ArrayList<>();

    // 取得した書類リストより返却用書類リストを作成
    for (CodeEntity codeEntity : docList) {

      DocumentDto documentDto = new DocumentDto();
      documentDto.setDocumentId(codeEntity.getCode());
      documentDto.setDocumentName(codeEntity.getCodeName());

      documentList.add(documentDto);

    }
    // 返却用書類リストを返却
    return documentList;
  }

  /**
   * プルダウン生成用役職リストの作成
   * @return 役職リスト
   */
  public List<PositionDto> createPositionList() {

    // データベースより役職のみのリスト(役職リスト)を取得
    List<CodeEntity> yakushokuList = codeMapper.getCodeList(ClassificationCodeEnum.POSITION.getClassificationCode());

    // 返却用役職リスト
    List<PositionDto> positionList = new ArrayList<>();

    // 取得した役職リストより返却用役職リストを作成  
    for (CodeEntity codeEntity : yakushokuList) {

      PositionDto positionDto = new PositionDto();
      positionDto.setPositionId(codeEntity.getCode());
      positionDto.setPositionName(codeEntity.getCodeName());

      positionList.add(positionDto);
    }
    // 返却用役職リストを返却
    return positionList;
  }

  /**
   * 社員リスト作成
   * @return List<EmployeeMasterDto> 社員リスト
   */
  public List<EmployeeMasterDto> createEmployeeList() {

    // 全社員のidと名前を取得
    List<EmployeeMasterDto> employeeList = employeeMasterMapper.getAllEmployee();

    // 社員リストを返却
    return employeeList;
  }
}