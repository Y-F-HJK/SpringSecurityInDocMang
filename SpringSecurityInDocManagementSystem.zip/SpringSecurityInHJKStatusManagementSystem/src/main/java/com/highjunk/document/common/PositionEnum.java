package com.highjunk.document.common;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 役職enum
 * @author highJUnk
 */
@AllArgsConstructor
@Getter
public enum PositionEnum {
	
  TERAWAKI("000"),
  NAKAMURA("001"),
  KAWAGUCHI("002");
	
	private String id;

}
