package com.highjunk.document.entity;

import lombok.Data;

/**
 * 完了済書類管理テーブルエンティティ
 * @author HighJunk
 *
 */
@Data
public class CompletedDocumentManagementEntity {
  // 管理ID
  private int managementId;
  // 書類ID
  private String documentId;
  // 進捗ステータス
  private String progressStatus;
}