package com.highjunk.document.service;

import com.highjunk.document.form.PromotionRequestForm;

/**
 * 昇格申請サービス
 * @author HighJunk
 *
 */
public interface PromotionRequestService {
  
  /**
   * 昇格申請データベース登録処理
   * @param form 昇格申請フォーム
   * @return 成功時true
   */
  public Boolean savePromotionRequest(PromotionRequestForm form);
}
