
  /**
   * コンテキストパスを取得
   */
  let contextPath = $("#contextPath").text();

  const regexp = /\/$/;
  if (regexp.test(contextPath)) {
    contextPath = contextPath.replace("/", "");
  }

  /**
   * 書類選択画面へ遷移
   */
  let docSelect = document.querySelector('#docSelectBtn');

  docSelect.addEventListener('click', function() {

  let urlToDocumentSelection = contextPath + "/documentSelection";

  location.href= urlToDocumentSelection;
});

/** 
 * タスク一覧画面へ遷移
 */
  let showTasks = document.querySelector('#taskBtn');

  showTasks.addEventListener('click', function() {

  let urlToTasks = contextPath + "/tasks";

  location.href = urlToTasks;

});

/** 
 * 履歴一覧画面へ遷移
 */
  let showHistory = document.querySelector('#historyBtn');

  showHistory.addEventListener('click', function() {

  let urlToHistory = contextPath + "/history";

  location.href = urlToHistory;
});