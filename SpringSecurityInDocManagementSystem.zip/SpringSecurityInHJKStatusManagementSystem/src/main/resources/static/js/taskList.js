$(function(){

  // 取得したリストを配列に変換
  var taskData = document.getElementsByClassName('taskData');

  var documentId; // 書類ID
  var progressStatus; // 進捗コード
  var managementId; // 管理ID
  var userId = $('#userId').text();

  const data = document.getElementsByClassName('taskData');

  for(let i=0;i<data.length;i++) {
    data[i].querySelector('#openModal').addEventListener('click', e => createModal(e));
  }

  function createModal(e) {

    // 対象取得
    target = e.target;
    // 書類ID取得
    documentId = target.closest('tr').querySelectorAll('[name=documentId]')[0].value;
    // 進捗ステータス取得
    progressStatus = target.closest('tr').querySelectorAll('[name=progressStatus]')[0].value;
    // 管理IDを取得
    managementId = target.closest('tr').querySelectorAll('[name=managementId]')[0].value;

    // 出力モーダルを判定
    if(documentId == "001"){

      if(progressStatus == '010'){
        $('#modalArea').fadeIn();
      } else if(progressStatus == '020'){
        $('#modalArea2').fadeIn();
      } else if (progressStatus == '100'){
        $('#modalArea3').fadeIn();
      }else if (progressStatus == '200'){
        $('#modalArea4').fadeIn();
      } else{
        $('#modalArea5').fadeIn();
      }
    }

    // 画面を閉じる際にはすべて空文字を入れる
    $('#closeModal , #modalBg').click(function(){
      $('#target-comment').val();
      comment = $('#OfficerComment1').val();
      comment = $('#OfficerComment2').val();
      $('.modalArea').fadeOut();
    });

    // 送信データ
    var JSONdata = {
        managementId : managementId
    }

    //IF05　フォーム受信
  $.ajax({
    type:'POST',
    url: '/getPromotionRequestTaskDetail',
    data:JSON.stringify(JSONdata),
    contentType: "application/json",
    dataType: "json",
    acriptCharset:'utf-8'
  })

  .done(function(data) {
    // 入力された各コメントを取得
    // 申請者コメントを格納
    $("#applicantComment").val(data.applicantComment);
    // 対象者コメントを格納
    $("#targetComment").val(data.targetComment);
    // 役員①コメントを格納
    $("#OfficerComment1").val(data.OfficerComment1);
    // 役員②コメントを格納
    $("#OfficerComment2").val(data.OfficerComment2);
    // 進捗ステータスを格納
    $("#progressStatus").val(data.progressStatus);

    if (data) {
    } else {
      alert ('データを受信できませんでした');
    }

    }).fail(function() {
      alert ('通信に失敗しました');
    })

  }

  //  IF06　フォーム送信
  $('button[data-name="form-btn"]').click(function(){

    var comment;

    if(progressStatus == '010'){
      comment = $('#target-comment').val();
    } else if (progressStatus == '100'){
      comment = $('#OfficerComment1').val();
    }else if (progressStatus == '200'){
      comment = $('#OfficerComment2').val();
    } else{
      comment = '';
    }
    
    console.log(comment);

    // Ajax通信を開始
    $.ajax({
      type:'POST',
      url: '/updatePromotionRequest',
      dataType: "json",
      data:JSON.stringify({
        userId : userId, // ログインユーザーID
        managementId : managementId, //　管理ID
        proressStatus : progressStatus,  // 進捗ステータス
        comment : comment // コメント
      }),
      contentType: "application/json; charset=UTF-8",
    })
    .done(function(data) {
      if (data) {
        $('#modalArea').fadeOut();
      } else {
        $('.modalArea').fadeOut();
        alert ('申請を失敗しました');
      }
      }).fail(function() {
        $('.modalArea').fadeOut();
        alert ('通信に失敗しました');
      })
    });

});