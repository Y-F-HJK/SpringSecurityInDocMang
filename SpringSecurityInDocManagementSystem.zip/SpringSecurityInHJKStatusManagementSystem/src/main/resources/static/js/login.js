/**
 * ログインJS
 */

let login = document.querySelector('#loginBtn');

/**
 * ログイン処理
 */
login.addEventListener('click', function() {

  $('.login-input').removeClass('error');

  let userId = $("#loginId").val();
  let password = $("#loginPassword").val();

  // 空文字チェック
  if (userId == "" && password == "") {
    alert ('ユーザーIDとパスワードが未入力です');
    return;
  } else if (userId == "") {
    alert ('ユーザーIDが未入力です');
    return;
  } else if (password == "") {
    alert ('パスワードが未入力です');
    return;
  }
  form.submit();
})