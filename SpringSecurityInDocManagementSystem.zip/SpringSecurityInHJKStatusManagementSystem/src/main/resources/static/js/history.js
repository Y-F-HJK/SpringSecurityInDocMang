$(function () {
  //コンテキストパス
  let contextPath = $('#contextPath').text();
  const regexp = /\/$/;
  if (regexp.test(contextPath)) {
    contextPath = contextPath.replace("/", "");
  }

  // パス
  const history = '/history';
  const search = '/search';
  const detail = '/detail';

  // ユーザーID
  let userId;
  // 管理ID
  let managementId;
  // 書類ID
  let documentId;
  // 書類名
  let documentName;

  // 履歴詳細モーダル表示
  $('body').on('click', "button[name='openModal']", function() {
    managementId = $(this).attr('data-management-id');
    documentId = $(this).attr('data-document-id');
    documentName = $(this).closest('tr').children('td[data-name="documentName"]').text();

    $.ajax({
      type: 'POST',
      url: contextPath + history + detail,
      dataType: 'json',
      data: JSON.stringify({
        managementId : managementId,
        documentId : documentId
      }),
      contentType: "application/json; charset=UTF-8",
    })
    .done(function(data){
      deleteModalTable();
      createModalTbl(data, documentName);
      $('#modalArea').fadeIn();
    })
    .fail(function() {
      alert ('通信に失敗しました');
    })
  });

  // モーダル非表示
  $('#modalClose , #modalBg').click(function(){
    $('td[data-name="modalDetail"]').val('');
    $('#modalArea').fadeOut();
  });

  // 検索
  $('button[name="search"]').click(function () {
    userId = $('#userId').text();
    documentId = $('select[name="documentName"]').val();
    let appFlg = false;
    let completedFlg = false;
    let denialFlg = false;

    if ($('#application').prop('checked')) appFlg = true;
    if ($('#completion').prop('checked')) completedFlg = true;
    if ($('#denial').prop('checked'))denialFlg = true;

    $.ajax({
      type: 'POST',
      url: contextPath + history + search,
      dataType: 'json',
      data: JSON.stringify({
        userId : userId,
        documentId : documentId,
        appFlg : appFlg,
        completedFlg : completedFlg,
        denialFlg : denialFlg
      }),
      contentType: "application/json; charset=UTF-8",
    })
    .done(function(data) {
      deleteTable(); // tbl削除
      createTable(data); //tbl作成
    })
    .fail(function() {
      alert ('通信に失敗しました');
    })
  });

  // モーダル内テーブル作成
  function createModalTbl(data, documentName) {
    $('h2[data-name="documentName"]').text(documentName);
    let $modal = $('#action-history-modal');
    data.documentActionHistoryList.forEach(function(val){
      let $tbody = $('<tbody>');
      let $tr = $('<tr>');

      $tr
      .addClass('align-middle')
      .append(
        '<td>' + val.actionDay + '</td>',
        '<td>' + val.actionUserName + '</td>',
        '<td>' + val.actionContent + '</td>',
      );
      $tbody.append($tr);
      $modal.append($tbody);
    });
    $('tr[data-name="createDate"]').append('<td>' + data.createDate + '</td>');
    $('tr[data-name="approvalDate"]').append('<td>' + data.completeDate + '</td>');
    $('tr[data-name="applicantComment"]').append('<td>' + data.applicantComment + '</td>');
    $('tr[data-name="targetComment"]').append('<td>' + data.targetComment + '</td>');
    $('tr[data-name="officerComment1"]').append('<td>' + data.officerComment1 + '</td>');
    $('tr[data-name="officerComment2"]').append('<td>' + data.officerComment2 + '</td>');
    $('tr[data-name="officerComment3"]').append('<td>' + data.officerComment3 + '</td>');
  };

  // モーダル内履歴一覧削除
  function deleteModalTable() {
    $('#history-modal  td').remove();
    $('#action-history-modal tbody').remove();
  };

  // 履歴一覧削除
  function deleteTable() {
    $('#history-list tbody tr').remove();
  };

  // 履歴一覧作成
  function createTable(data) {
    data.forEach(function(val){
      let $historyTbody = $('#history-list tbody');
      let $historyTr = $('<tr>');

      $historyTr
      .addClass('align-middle')
      .append(
        '<td>' + val.createDate + '</td>',
        '<td data-name="documentName">' + val.documentName + '</td>',
        '<td>' + val.applicantName + '</td>',
        '<td>' + val.progressStatus + '</td>',
        '<td data-name="detail"><button name="openModal" class="history-btn" data-management-id="' + val.managementId + '" data-document-id="' + val.documentId + '" value="詳細">詳細</button></td>'
      )
    $historyTbody.append($historyTr);
    });
  };
});