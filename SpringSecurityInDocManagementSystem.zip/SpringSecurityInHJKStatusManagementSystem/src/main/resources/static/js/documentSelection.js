/**
 * モーダル開閉
 */
$(function () {

  // 書類を選択した際にモーダルを開く
  $('button[data-name="openModal"]').click(function(){
    let userId = $("#userId");
    if (!userId) {
      return;
    }
    var documentId = $(this).closest('div').children('#documnetId').text();
    if(documentId == '001') {
      $('#promotionModal').fadeIn();
    }else {
      alert ('モーダルがありません');
    }
  });

  // 画面を閉じる際にはすべて空文字を入れる
  $('div[data-name="modalClose"] , div[data-name="modalBg"]').click(function(){
    $('.applicant-comment-input').val('');
    $('.modalArea').fadeOut();
  });

  $('input[name="returnBtn"]').click(function(){
    $("#form").submit();
  });

  /** 
   * フォーム送信
   */
  $("#eligiblePromotionSubmit").click(function(){

  // コメントの文字数チェック
  // コメントに入力された文字数が空または●●文字以上の場合
  if($("#comment").val() == '' || $("#comment").val().length >= 200 ) {

    $('#is-error-comment').show();
    return false;

  } else {

    $('#is-error-comment').hide();

    var JSONdata = {
      // ユーザーID
      userId : document.getElementById('userId').getAttribute('value'),
      // 現役職コード
      positionCode : $("#position").val(),
      // 昇格後役職コード
      afterPositionCode : $("#afterPosition").val(),
      // 対象者名
      targetId : $("#eligibleForPromotion").val(),
      // コメント
      comment : $("#comment").val(),
      // 次の作業者
      nextWriterId : $("#nextWriter").val()

    }

    // Ajax通信を開始
    $.ajax({    
       type:'POST',
       url: '/savePromotionRequest',
       data:JSON.stringify(JSONdata),
       contentType: "application/json",
       dataType: "json",
       acriptCharset:'utf-8'
    })
    .done(function(data) {
      if (data) {
        $('.modalArea').fadeOut();
        alert ('新規作成が完了しました');
      } else {
        $('.modalArea').fadeOut();
        alert ('新規作成に失敗しました');
      }

      $('.applicant-comment-input').val('');

      }).fail(function() {
        $('.modalArea').fadeOut();
        alert ('通信に失敗しました');
        $('.applicant-comment-input').val('');
      })
    }
  });
});