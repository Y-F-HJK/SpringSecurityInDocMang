-- 社員マスタ(テストデータ) --
INSERT INTO employee_master (employee_id, employee_name, mail_address, department_id, position_id) VALUES ('001', '社長', 'test@gmail.com', '02', '01');
INSERT INTO employee_master (employee_id, employee_name, mail_address, department_id, position_id) VALUES ('002', '役員1', 'test@gmail.com', '02', '01');
INSERT INTO employee_master (employee_id, employee_name, mail_address, department_id, position_id) VALUES ('003', '役員2', 'test@gmail.com', '02', '01');
INSERT INTO employee_master (employee_id, employee_name, mail_address, department_id, position_id) VALUES ('004', '係長', 'test@gmail.com', '02', '02');
INSERT INTO employee_master (employee_id, employee_name, mail_address, department_id, position_id) VALUES ('005', '主任', 'test@gmail.com', '02', '03');
INSERT INTO employee_master (employee_id, employee_name, mail_address, department_id, position_id) VALUES ('006', '準主任', 'test@gmail.com', '02', '04');
INSERT INTO employee_master (employee_id, employee_name, mail_address, department_id, position_id) VALUES ('007', '一般', 'test@gmail.com', '02', '05');
INSERT INTO employee_master (employee_id, employee_name, mail_address, department_id, position_id) VALUES ('008', '研修卒業', 'test@gmail.com', '02', '06');
INSERT INTO employee_master (employee_id, employee_name, mail_address, department_id, position_id) VALUES ('009', '研修', 'test@gmail.com', '02', '07');

-- ユーザー情報(テストデータ) --
INSERT INTO user_info (employee_id, password) VALUES ('001', '$2a$10$7DPK77gJffvBGmMmvmc4xuiLyoQoG6vtIzx49nzMhGy0ASS0aG4F2');
INSERT INTO user_info (employee_id, password) VALUES ('002', '$2a$10$7DPK77gJffvBGmMmvmc4xuiLyoQoG6vtIzx49nzMhGy0ASS0aG4F2');
INSERT INTO user_info (employee_id, password) VALUES ('003', '$2a$10$7DPK77gJffvBGmMmvmc4xuiLyoQoG6vtIzx49nzMhGy0ASS0aG4F2');
INSERT INTO user_info (employee_id, password) VALUES ('004', '$2a$10$7DPK77gJffvBGmMmvmc4xuiLyoQoG6vtIzx49nzMhGy0ASS0aG4F2');
INSERT INTO user_info (employee_id, password) VALUES ('005', '$2a$10$7DPK77gJffvBGmMmvmc4xuiLyoQoG6vtIzx49nzMhGy0ASS0aG4F2');
INSERT INTO user_info (employee_id, password) VALUES ('006', '$2a$10$7DPK77gJffvBGmMmvmc4xuiLyoQoG6vtIzx49nzMhGy0ASS0aG4F2');
INSERT INTO user_info (employee_id, password) VALUES ('007', '$2a$10$7DPK77gJffvBGmMmvmc4xuiLyoQoG6vtIzx49nzMhGy0ASS0aG4F2');
INSERT INTO user_info (employee_id, password) VALUES ('008', '$2a$10$7DPK77gJffvBGmMmvmc4xuiLyoQoG6vtIzx49nzMhGy0ASS0aG4F2');
INSERT INTO user_info (employee_id, password) VALUES ('009', '$2a$10$7DPK77gJffvBGmMmvmc4xuiLyoQoG6vtIzx49nzMhGy0ASS0aG4F2');

-- CODE インサート文 --
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('5000', '進捗', '001', '作成');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('5000', '進捗', '010', '部下更新待ち');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('5000', '進捗', '020', '上司承認待ち');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('5000', '進捗', '100', '役員承認待ち(川口さん)');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('5000', '進捗', '200', '役員承認待ち(中村さん)');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('5000', '進捗', '300', '社長承認待ち');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('5000', '進捗', '400', '社長承認済み');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('5000', '進捗', '999', '否認');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('0001', '部署', '01', '総務');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('0001', '部署', '02', 'システム開発');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('0100', '役職', '01', '役員');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('0100', '役職', '02', '係長');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('0100', '役職', '03', '主任');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('0100', '役職', '04', '準主任');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('0100', '役職', '05', '一般');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('0100', '役職', '06', '研修卒業');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('0100', '役職', '07', '研修');
INSERT INTO code (bunrui_code, bunrui_name, code, code_name) VALUES ('1000', '書類', '001', '昇格申請書');