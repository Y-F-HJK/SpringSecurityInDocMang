-- 社員マスタ --
CREATE TABLE `employee_master` (
  `employee_id` char(3) NOT NULL,
  `employee_name` varchar(30) NOT NULL,
  `mail_address` varchar(256) NOT NULL,
  `department_id` char(2) NOT NULL,
  `position_id` char(2) NOT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- コード --
CREATE TABLE `code` (
  `bunrui_code` char(5) NOT NULL,
  `bunrui_name` varchar(30) NOT NULL,
  `code` char(5) NOT NULL,
  `code_name` varchar(30) NOT NULL,
  PRIMARY KEY (`bunrui_code`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ユーザー情報 --
CREATE TABLE `user_info` (
  `employee_id` char(3) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 書類進捗管理 --
CREATE TABLE `document_progress_management` (
  `management_id` int NOT NULL,
  `document_id` char(5) NOT NULL,
  `employee_id` char(3),
  `progress_status` char(3),
  `create_date` datetime,
  `update_date` datetime,
  PRIMARY KEY (`management_id`, `document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 完了済書類管理 --
CREATE TABLE `completed_document_management` (
  `management_id` int NOT NULL,
  `document_id` char(5) NOT NULL,
  `progress_status` char(3),
  PRIMARY KEY (`management_id`, `document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 書類履歴 --
CREATE TABLE `document_history` (
  `management_id` int NOT NULL,
  `document_id` char(5) NOT NULL,
  `employee_id` char(3),
  `progress_status` char(3) NOT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`management_id`, `document_id`, `progress_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 昇格申請書tbl --
CREATE TABLE `promotion_request` (
  `management_id` int AUTO_INCREMENT NOT NULL,
  `before_position_id` char(2),
  `after_position_id` char(2),
  `applicant_employee_id` char(3),
  `target_employee_id` char(3),
  `applicant_comment` text,
  `target_comment` text,
  `officer_comment1` text,
  `officer_comment2` text,
  `officer_comment3` text,
  `approval_date` date,
  `create_date` datetime,
  `update_date` datetime,
  PRIMARY KEY (`management_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
