package com.highjunk.document;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HighJunkDocumentManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
